"use strict";
(self.webpackChunkng_turbo_games = self.webpackChunkng_turbo_games || []).push([
    [171], {
        9171: (xt, T, l) => {
            l.r(T), l.d(T, {
                MiniRouletteModule: () => bt
            });
            var F = l(9808),
                H = l(4996),
                M = l(6352),
                P = l(8248),
                V = l(7303),
                U = l(655),
                p = l(4987),
                w = l(7258),
                D = l(9635),
                B = l(9300),
                R = l(1361),
                I = l(8044),
                Y = l(4946),
                g = l(4431),
                u = l(2398),
                c = l(162),
                m = l(8514),
                Z = l(4884),
                z = l(7802),
                A = l(5111),
                J = l(8351);
            const f = 39,
                b = 83.5,
                v = 106,
                N = {
                    highlight1: {
                        x: -b,
                        y: b
                    },
                    highlight2: {
                        x: v,
                        y: -f
                    },
                    highlight3: {
                        x: f,
                        y: v
                    },
                    highlight4: {
                        x: -b,
                        y: -b
                    },
                    highlight5: {
                        x: -v,
                        y: -f
                    },
                    highlight6: {
                        x: f,
                        y: -v
                    },
                    highlight7: {
                        x: b,
                        y: b
                    },
                    highlight8: {
                        x: v,
                        y: f
                    },
                    highlight9: {
                        x: -v,
                        y: f
                    },
                    highlight10: {
                        x: -f,
                        y: -v
                    },
                    highlight11: {
                        x: -f,
                        y: v
                    },
                    highlight12: {
                        x: b,
                        y: -b
                    }
                },
                x = Object.freeze({
                    num_length: 12,
                    sectors: {
                        s: [
                            [1, 2, 3, 4],
                            [3, 4, 5, 6],
                            [5, 6, 7, 8],
                            [7, 8, 9, 10],
                            [9, 10, 11, 12]
                        ],
                        h: [
                            [1, 2],
                            [3, 4],
                            [5, 6],
                            [7, 8],
                            [9, 10],
                            [11, 12]
                        ],
                        v: [
                            [1, 3],
                            [2, 4],
                            [3, 5],
                            [4, 6],
                            [5, 7],
                            [6, 8],
                            [7, 9],
                            [8, 10],
                            [9, 11],
                            [10, 12]
                        ]
                    },
                    buttons: {
                        half1: [1, 2, 3, 4, 5, 6],
                        even: [2, 4, 6, 8, 10, 12],
                        black: [2, 4, 6, 7, 9, 11],
                        red: [1, 3, 5, 8, 10, 12],
                        odd: [1, 3, 5, 7, 9, 11],
                        half2: [7, 8, 9, 10, 11, 12]
                    }
                });
            var G = l(7579),
                S = l(1420);
            class L {
                constructor(e, i) {
                    this.stage = e, this.gameConfig = i, this.data = null, this.history = null, this.updateChips = new G.x, this.updateChips$ = this.updateChips.asObservable()
                }
                getAllChip() {
                    let e = null;
                    return this.data && (e = {}, Object.keys(this.data).forEach(i => {
                        this.data[i] && (e[i] = this.data[i].value)
                    })), e
                }
                get totalBet() {
                    let e = 0;
                    return this.data && Object.keys(this.data).forEach(i => {
                        this.data[i] && (e = w.t.sum(e, this.data[i].value).toNumber())
                    }), e
                }
                addChip(e, i = null, n = 0) {
                    null == this.data && (this.data = {}), null == this.history && (this.history = []);
                    const a = e.name;
                    if (this.data.hasOwnProperty(a)) this.data[a].value += i, this.history.push({
                        value: this.gameConfig.chipsCost[n],
                        key: a
                    }), this.stage.removeChild(this.data[a]), this.stage.addChild(this.data[a]);
                    else {
                        const s = i,
                            h = new S.A(s, this.gameConfig.chipsCost);
                        h.x = e.x, h.y = e.y, this.data[a] = h, this.history.push({
                            value: s,
                            key: a
                        }), this.stage.addChild(h)
                    }
                    this.updateChips.next()
                }
                undoChip() {
                    if (this.history && this.history.length > 0) {
                        const e = this.history[this.history.length - 1],
                            i = this.data[e.key],
                            n = i.value;
                        n - e.value > 0 ? i.value = n - e.value : (this.stage.removeChild(i), delete this.data[e.key]), this.history.pop()
                    }
                    this.updateChips.next()
                }
                clearAllChip() {
                    null != this.data && (Object.keys(this.data).forEach(e => {
                        this.data[e] && this.stage.removeChild(this.data[e]), this.data[e] = null
                    }), this.data = null, this.history = null, this.updateChips.next())
                }
                createReBet() {
                    this.reBet = {
                        history: this.history.slice(),
                        data: {}
                    }, Object.keys(this.data).forEach(e => {
                        this.reBet.data[e] = {
                            value: this.data[e].value,
                            x: this.data[e].x,
                            y: this.data[e].y
                        }
                    }), this.updateChips.next()
                }
                clearLost(e, i = !0) {
                    const n = this.history;
                    Object.keys(this.data).forEach(a => {
                        let s = x.buttons[a];
                        s || (s = x.sectors[a.slice(0, 1)], s = s ? s[a.slice(1)] : a.slice(1)), (Array.isArray(s) && !s.includes(e) || Number.isInteger(+s) && e != s) && (m.J.tween(this.data[a], i ? .5 : 0, {
                            alpha: 0,
                            onComplete: r => {
                                this.stage.removeChild(r)
                            },
                            onCompleteParams: [this.data[a]]
                        }), delete this.data[a])
                    }), this.history = [];
                    for (let a = 0; a < n.length; a++) this.data.hasOwnProperty(n[a].key) && this.history.push(n[a]);
                    this.updateChips.next()
                }
                reBetChip() {
                    this.history = this.reBet.history.slice(), this.data = {}, Object.keys(this.reBet.data).forEach(e => {
                        const i = new S.A(this.reBet.data[e].value, this.gameConfig.chipsCost);
                        i.x = this.reBet.data[e].x, i.y = this.reBet.data[e].y, this.data[e] = i, this.stage.addChild(i)
                    }), this.updateChips.next()
                }
            }
            const O = (o, e, i = 60, n = 30, a = 30) => new c.E9j((o - 1) * i + n, (e - 1) * i + a);
            class W extends z.f {
                constructor(e, i, n, a, s) {
                    super(e, i, !0, {
                        width: 360,
                        height: 181,
                        autoDensity: !1,
                        autoStart: !1
                    }, !0), this.config = n, this.gameConfig = a, this.translocoService = s, this.board = {}, this.boardConfig = x, this.currentChipCost = 0, this.timelineRef = null, this.initBoard();
                    const h = new c.jyi(c.xEZ.from("mr_board_grid"));
                    h.width = 360, h.height = 181, this.stage.addChild(h), this.chipManager = new L(this.stage, a), this.manualUpdate()
                }
                initBoard() {
                    for (let e = 1; e <= this.boardConfig.num_length; e++) {
                        const {
                            col: i,
                            row: n
                        } = {
                            col: (0, A.r)(o = e) ? (o - 1) / 2 + 1 : o / 2,
                            row: (0, A.r)(o) ? 2 : 1
                        }, a = O(i, n);
                        this.initBoardSprite("bg_n" + e, (0, Z.AK)(), a, !1), this.initBoardSprite("n" + e, (0, Z.AK)(58, 58, 16711680), a, !0)
                    }
                    var o;
                    Object.keys(this.boardConfig.buttons).forEach((e, i) => {
                        const a = O(i + 1, 3);
                        this.initBoardSprite("bg_" + e, (0, Z.AK)(), a, !1), this.initBoardSprite(e, (0, Z.AK)(58, 58, 16711680), a, !0), ("odd" === e || "even" === e) && this.initText((0, J.ct)(e), a)
                    }), Object.keys(this.boardConfig.sectors).reverse().forEach(e => {
                        for (let i = 0; i < this.boardConfig.sectors[e].length; i++) {
                            const n = e + i,
                                a = "s" !== e ? (0, Z.AK)(60, 14, 16711935) : (0, Z.AL)();
                            if (this.initBoardSprite(n, a, new c.E9j(0, 0), !0), "h" === e || "s" === e) {
                                const s = new c.E9j(60 * i, 60);
                                this.board[n].y = s.y, this.board[n].x = s.x, this.board[n].x += "s" === e ? 60 : 30
                            } else if ("v" === e) {
                                const s = i + 1,
                                    h = (0, A.r)(s) ? (s - 1) / 2 + 1 : s / 2,
                                    r = (0, A.r)(s) ? 2 : 1,
                                    d = O(h, r, 60, 60);
                                this.board[n].x = d.x, this.board[n].y = d.y, this.board[n].angle = 90
                            }
                        }
                    })
                }
                initText(e, i) {
                    const a = new c.xvT(`${this.translocoService.translate(`shared.${e}`)}`, {
                        fontFamily: "Roboto",
                        fill: 4294967248,
                        fontSize: 12,
                        align: "center"
                    });
                    a.pivot.set(a.width / 2, a.height / 2), a.position.copyFrom(i), this.stage.addChild(a)
                }
                initBoardSprite(e, i, n, a) {
                    i.x = n.x, i.y = n.y, i.alpha = 0, i.name = e, a && (i.alpha = 0, i.name = e, i.cursor = "pointer", i.interactive = !0, i.on("mouseout", this.onHover, this), i.on("mouseover", this.onHover, this), i.on("pointertap", this.onClick, this)), this.stage.addChild(i), this.board[e] = i
                }
                onHover(e) {
                    const i = e.currentTarget.name,
                        n = "mouseover" == e.type ? .4 : 0,
                        a = "bg_" + i;
                    if (this.board.hasOwnProperty(a)) {
                        if (this.board[a].alpha = n, this.boardConfig.buttons.hasOwnProperty(i)) {
                            const s = this.boardConfig.buttons[i];
                            for (let h = 0; h < s.length; h++) this.board["bg_n" + s[h]].alpha = n
                        }
                    } else {
                        const s = i.substring(0, 1),
                            h = i.substring(1, 2),
                            r = this.boardConfig.sectors[s][h];
                        for (let d = 0; d < r.length; d++) this.board["bg_n" + r[d]].alpha = n
                    }
                    setTimeout(() => {
                        this.manualUpdate()
                    })
                }
                onClick(e) {
                    const i = e.currentTarget,
                        n = this.gameConfig.limits[i.name] || this.gameConfig.limits[i.name.slice(0, 1)],
                        a = this.chipManager.getAllChip() && this.chipManager.getAllChip()[i.name] || 0,
                        s = this.chipManager.totalBet,
                        h = this.gameConfig.limits.total.max;
                    let r = this.gameConfig.chipsCost[this.currentChipCost];
                    a + r < n.min && (r = n.min), a + r > n.max && (r = n.max - a), s + r > h && (r = h - s), a >= n.max || s >= h || 0 === a && r < n.min && s + r >= h ? this.emitEvent("onBetLimit") : (this.chipManager.addChip(i, r, this.currentChipCost), this.emitEvent("onAddChip"), this.manualUpdate())
                }
                updateCurrentChipCost(e) {
                    this.currentChipCost = e
                }
                highlightCell(e) {
                    this.timelineRef && this.timelineRef.kill && this.timelineRef.kill();
                    const i = this.board[`bg_n${e}`];
                    this.timelineRef = m.J.timeline({
                        repeat: 3,
                        onUpdate: () => {
                            this.manualUpdate()
                        }
                    }, [{
                        tween: m.J.tween(i, .5, {
                            alpha: .9
                        })
                    }, {
                        tween: m.J.tween(i, .5, {
                            alpha: 0
                        })
                    }])
                }
                manualUpdate() {
                    this.app.ticker.update()
                }
                destroy() {
                    super.destroy()
                }
            }
            var t = l(7587),
                j = l(9039),
                _ = l(2821),
                Q = l(1560);

            function K(o, e) {
                if (1 & o) {
                    const i = t.EpF();
                    t.ynx(0), t.TgZ(1, "div", 1), t.TgZ(2, "h5", 2), t._uU(3), t.qZA(), t.TgZ(4, "button", 3), t.NdJ("click", function() {
                        return t.CHM(i), t.oxw().onClose()
                    }), t.TgZ(5, "span", 4), t._uU(6, "\xd7"), t.qZA(), t.qZA(), t.qZA(), t.TgZ(7, "div", 5), t.TgZ(8, "div", 6), t.TgZ(9, "div", 7), t.O4$(), t.TgZ(10, "svg", 8), t.TgZ(11, "defs"), t.TgZ(12, "linearGradient", 9), t._UZ(13, "stop", 10), t._UZ(14, "stop", 11), t.qZA(), t.TgZ(15, "linearGradient", 12), t._UZ(16, "stop", 13), t._UZ(17, "stop", 14), t.qZA(), t.qZA(), t.TgZ(18, "g", 15), t.TgZ(19, "g", 16), t._UZ(20, "circle", 17), t._UZ(21, "circle", 18), t._UZ(22, "circle", 19), t._UZ(23, "circle", 20), t._UZ(24, "circle", 21), t._UZ(25, "circle", 22), t._UZ(26, "circle", 23), t._UZ(27, "circle", 24), t._UZ(28, "circle", 25), t._UZ(29, "circle", 26), t._UZ(30, "circle", 27), t._UZ(31, "circle", 28), t._UZ(32, "circle", 29), t._UZ(33, "circle", 30), t._UZ(34, "path", 31), t.qZA(), t._UZ(35, "path", 32), t._UZ(36, "path", 33), t.TgZ(37, "text", 34), t.TgZ(38, "tspan", 35), t._uU(39), t.qZA(), t.qZA(), t.TgZ(40, "text", 36), t.TgZ(41, "tspan", 37), t._uU(42, "7-12"), t.qZA(), t.qZA(), t.TgZ(43, "text", 38), t.TgZ(44, "tspan", 39), t._uU(45), t.qZA(), t.qZA(), t.TgZ(46, "text", 40), t.TgZ(47, "tspan", 41), t._uU(48, "1-6"), t.qZA(), t.qZA(), t._UZ(49, "path", 42), t._UZ(50, "path", 43), t._UZ(51, "path", 44), t._UZ(52, "path", 45), t._UZ(53, "path", 46), t._UZ(54, "path", 47), t._UZ(55, "path", 48), t.TgZ(56, "g", 49), t._UZ(57, "path", 50), t._UZ(58, "path", 51), t.qZA(), t.TgZ(59, "g", 49), t._UZ(60, "path", 52), t._UZ(61, "path", 53), t.qZA(), t._UZ(62, "path", 54), t._UZ(63, "path", 55), t.qZA(), t.qZA(), t.kcU(), t.TgZ(64, "div", 56), t._uU(65), t.ALo(66, "decimalMultiplier"), t.qZA(), t.TgZ(67, "div", 57), t._uU(68), t.ALo(69, "decimalMultiplier"), t.qZA(), t.TgZ(70, "div", 58), t._uU(71), t.ALo(72, "decimalMultiplier"), t.qZA(), t.TgZ(73, "div", 59), t._uU(74), t.ALo(75, "decimalMultiplier"), t.qZA(), t.TgZ(76, "div", 60), t._uU(77), t.ALo(78, "decimalMultiplier"), t.qZA(), t.TgZ(79, "div", 61), t._uU(80), t.ALo(81, "decimalMultiplier"), t.qZA(), t.qZA(), t.qZA(), t.qZA(), t.BQk()
                }
                if (2 & o) {
                    const i = e.$implicit,
                        n = t.oxw();
                    t.xp6(3), t.hij(" ", i("shared.Paytable"), " "), t.xp6(36), t.hij(" ", i("shared.Odd"), " "), t.xp6(6), t.hij(" ", i("shared.Even"), " "), t.xp6(20), t.hij("", t.lcZ(66, 9, n.gameConfig.payTable.numAmount1), "x"), t.xp6(3), t.hij("", t.lcZ(69, 11, n.gameConfig.payTable.numAmount2), "x"), t.xp6(3), t.hij("", t.lcZ(72, 13, n.gameConfig.payTable.numAmount4), "x"), t.xp6(3), t.hij("", t.lcZ(75, 15, n.gameConfig.payTable.numAmount6), "x"), t.xp6(3), t.hij("", t.lcZ(78, 17, n.gameConfig.payTable.numAmount6), "x"), t.xp6(3), t.hij("", t.lcZ(81, 19, n.gameConfig.payTable.numAmount6), "x")
                }
            }
            let k = (() => {
                class o {
                    constructor(i, n) {
                        this.activeModal = i, this.core = n
                    }
                    onClose() {
                        this.activeModal.close()
                    }
                    get gameConfig() {
                        return this.core.gameConfig
                    }
                }
                return o.\u0275fac = function(i) {
                    return new(i || o)(t.Y36(j.Kz), t.Y36(_.p))
                }, o.\u0275cmp = t.Xpm({
                    type: o,
                    selectors: [
                        ["app-paytable"]
                    ],
                    decls: 1,
                    vars: 0,
                    consts: [
                        [4, "transloco"],
                        [1, "modal-header"],
                        [1, "modal-title", "text-uppercase"],
                        ["type", "button", "data-dismiss", "modal", "aria-label", "Close", 1, "close", 3, "click"],
                        ["aria-hidden", "true"],
                        [1, "modal-body"],
                        [1, "d-flex", "justify-content-center", "align-items-center"],
                        [1, "paytable-svg"],
                        ["xmlns", "http://www.w3.org/2000/svg", "width", "303", "height", "234", "viewBox", "0 0 303 234"],
                        ["id", "paytableRed", "x1", "12.2%", "x2", "86.2%", "y1", "100%", "y2", "18.4%"],
                        ["offset", "0%", "stop-color", "#D90525"],
                        ["offset", "100%", "stop-color", "#EA0224"],
                        ["id", "paytableBlack", "x1", "16.9%", "x2", "82.5%", "y1", "100%", "y2", "6.2%"],
                        ["offset", "0%", "stop-color", "#070505"],
                        ["offset", "100%", "stop-color", "#362222"],
                        ["fill", "none", "fill-rule", "evenodd"],
                        ["fill-rule", "nonzero", "transform", "translate(8 41)"],
                        ["cx", "18.5", "cy", "68.5", "r", "18.5", "fill", "url(#paytableRed)"],
                        ["cx", "18.5", "cy", "18.5", "r", "18.5", "fill", "url(#paytableBlack)"],
                        ["cx", "68.5", "cy", "68.5", "r", "18.5", "fill", "url(#paytableRed)"],
                        ["cx", "68.5", "cy", "18.5", "r", "18.5", "fill", "url(#paytableBlack)"],
                        ["cx", "118.5", "cy", "68.5", "r", "18.5", "fill", "url(#paytableRed)"],
                        ["cx", "118.5", "cy", "18.5", "r", "18.5", "fill", "url(#paytableBlack)"],
                        ["cx", "168.5", "cy", "68.5", "r", "18.5", "fill", "url(#paytableBlack)"],
                        ["cx", "218.5", "cy", "68.5", "r", "18.5", "fill", "url(#paytableBlack)"],
                        ["cx", "268.5", "cy", "68.5", "r", "18.5", "fill", "url(#paytableBlack)"],
                        ["cx", "168.5", "cy", "18.5", "r", "18.5", "fill", "url(#paytableRed)"],
                        ["cx", "218.5", "cy", "18.5", "r", "18.5", "fill", "url(#paytableRed)"],
                        ["cx", "268.5", "cy", "18.5", "r", "18.5", "fill", "url(#paytableRed)"],
                        ["cx", "118.5", "cy", "119.5", "r", "18.5", "fill", "url(#paytableBlack)"],
                        ["cx", "169.5", "cy", "119.5", "r", "18.5", "fill", "url(#paytableRed)"],
                        ["fill", "#FFF", "d", "M13.8 26v-2.6l5.9-6.8.6-.9.2-1c0-.6-.2-1-.5-1.4a2 2 0 0 0-1.4-.5h-.7l-.6.4-.4.6c-.2.3-.2.6-.2 1h-2.9c0-.7.1-1.4.4-2a4.1 4.1 0 0 1 2.5-2.3c.6-.2 1.2-.3 1.9-.3s1.3.1 2 .3c.5.2 1 .5 1.4 1 .4.3.8.8 1 1.4a5 5 0 0 1 0 3.7l-.6.9-.7.8-4.4 5.1h6V26h-9.5Zm58.6-2.2V26h-2.8v-2.2h-6.4v-2.7l5.4-10.8h3.1l-5.4 10.8h3.3v-3h2.8v3h1.4v2.7zm51-2.6c0 .8-.2 1.5-.4 2.1a4.4 4.4 0 0 1-2.6 2.5 6 6 0 0 1-2 .3c-.6 0-1.3 0-1.9-.3-.6-.2-1-.5-1.5-1a3 3 0 0 1-1-1.4 5.7 5.7 0 0 1 0-4.2c.2-.7.6-1.4.9-2l3.3-6.9h3.1l-3.2 6.5.6-.2a4 4 0 0 1 2 .3 4.1 4.1 0 0 1 2.3 2.4c.2.6.4 1.2.4 2Zm-3 0c0-.6 0-1.2-.5-1.6-.3-.4-.8-.6-1.4-.6a2 2 0 0 0-1.5.6c-.4.4-.6 1-.6 1.7s.2 1.3.6 1.7c.4.4.9.6 1.5.6s1-.2 1.4-.6c.4-.4.6-1 .6-1.7Zm53.1.2a4 4 0 0 1-.4 2 4 4 0 0 1-1 1.5l-1.6 1a6 6 0 0 1-5.5-1c-.5-.4-.8-.9-1.1-1.4a4.8 4.8 0 0 1-.2-3.3 4.2 4.2 0 0 1 1.8-2.3 3.7 3.7 0 0 1-1.2-1.2 4 4 0 0 1-.6-2 4.3 4.3 0 0 1 1.4-3.3 5.5 5.5 0 0 1 5.2-.9 4.3 4.3 0 0 1 2.8 5.3 4 4 0 0 1-1.6 2.1l.7.6a4.2 4.2 0 0 1 1.1 1.7c.2.3.2.8.2 1.2Zm-2.8 0a2.1 2.1 0 0 0-2.2-2.2 2.1 2.1 0 0 0-2.2 2.2 2 2 0 0 0 2.2 2.2 2 2 0 0 0 2.2-2.2Zm-.3-6.6c0-.6-.1-1-.5-1.5-.4-.3-.8-.5-1.4-.5-.5 0-1 .2-1.4.5a2 2 0 0 0-.5 1.5 2 2 0 0 0 2 2c.5 0 1-.2 1.3-.6.4-.4.5-.9.5-1.4ZM212 26V13.4l-3.2 2.8v-3l3.2-2.9h2.9V26H212Zm17.2-4.5c0 .7 0 1.4-.3 2a4.3 4.3 0 0 1-2.6 2.3 5.4 5.4 0 0 1-5.2-.9l-1-1.4c-.3-.6-.4-1.3-.4-2v-6.6c0-.8.1-1.4.4-2a4.3 4.3 0 0 1 2.6-2.4 5.4 5.4 0 0 1 5.1 1c.4.3.8.8 1 1.4.3.6.4 1.2.4 2v6.6Zm-2.8-6.6c0-.6-.2-1.2-.6-1.6-.3-.3-.8-.5-1.3-.5-.6 0-1 .2-1.4.5-.4.4-.5 1-.5 1.6v6.5c0 .7.1 1.2.5 1.6.4.4.8.6 1.4.6.5 0 1-.2 1.3-.6.4-.4.6-.9.6-1.6V15ZM18 76V63.4l-3.2 2.8v-3.1l3.2-2.8h2.8V76zm55.4-4.5a5 5 0 0 1-.4 2 4.1 4.1 0 0 1-2.6 2.3 6.3 6.3 0 0 1-3.8 0 4 4 0 0 1-2.7-2.3 5 5 0 0 1-.4-2h2.8c0 .4 0 .7.2 1l.5.6.6.3.8.2c.7 0 1.2-.2 1.6-.6.4-.4.6-1 .6-1.6 0-.7-.2-1.2-.6-1.6-.4-.4-1-.6-1.6-.6h-.5v-2.5h.5c.7 0 1.2-.1 1.5-.5.3-.4.4-.9.4-1.4 0-.7-.2-1.2-.5-1.5a2 2 0 0 0-1.4-.5 2 2 0 0 0-1.3.5 2 2 0 0 0-.6 1.4h-2.9c0-.7.2-1.4.4-2a4.3 4.3 0 0 1 2.6-2.2 5.5 5.5 0 0 1 5.3 1c.4.4.7.8 1 1.4a4.8 4.8 0 0 1-.2 3.8c-.4.5-.8 1-1.3 1.2.6.3 1 .7 1.4 1.3.4.6.6 1.3.6 2.3Zm50-.8c0 .9 0 1.7-.3 2.3a4 4 0 0 1-1 1.9l-1.5.9c-.5.2-1.2.3-2 .3-.9 0-1.6 0-2.2-.3-.5-.3-1-.6-1.3-1-.5-.4-.8-1-1-1.5-.2-.5-.3-1.1-.3-1.7h2.8c.1.6.3 1.1.6 1.5.3.3.8.5 1.4.5.5 0 1-.2 1.3-.5.3-.3.4-.6.5-1l.1-1.4c0-.9-.1-1.6-.4-2-.3-.6-.8-.8-1.5-.8-.6 0-1 .1-1.3.4l-.6.9h-2.6v-8.9h9V63h-6.4v3.4l1-.6a4.7 4.7 0 0 1 3.1 0l1.2.8c.6.7 1 1.3 1.2 2l.2 2.2Zm46.1 5.3h-3.1l5.1-13.1h-4.1v2.5h-2.8v-5.1h10v2.6zm53.9-11c0 .8-.1 1.5-.4 2.1l-.9 2.1-3.3 6.8h-3.1l3.3-6.5-.6.2A4 4 0 0 1 214 67a5.4 5.4 0 0 1 0-4 4.4 4.4 0 0 1 2.6-2.5 6.3 6.3 0 0 1 3.9 0c.6.2 1 .5 1.5 1 .4.4.8.9 1 1.5.3.6.4 1.3.4 2Zm-2.8 0c0-.7-.2-1.2-.6-1.6a2 2 0 0 0-1.5-.6 2 2 0 0 0-1.4.6c-.4.4-.6 1-.6 1.7s.2 1.2.6 1.6c.3.4.8.7 1.4.7a2 2 0 0 0 1.5-.6c.4-.4.6-1 .6-1.7ZM262 26V13.4l-3.2 2.8v-3l3.2-2.9h2.9V26H262Zm7.8 0v-2.6l5.8-6.8c.3-.3.6-.6.7-.9l.2-1c0-.6-.2-1-.5-1.4a2 2 0 0 0-1.4-.5h-.7l-.6.4-.5.6-.1 1h-2.9c0-.7.1-1.4.4-2a4.1 4.1 0 0 1 2.5-2.3c.6-.2 1.2-.3 1.9-.3s1.3.1 1.9.3c.6.2 1 .5 1.5 1 .4.3.7.8 1 1.4a5 5 0 0 1-.1 3.7l-.5.9-.7.8-4.4 5.1h6V26h-9.5ZM262 76V63.4l-3.2 2.8v-3l3.2-2.9h2.9V76H262Zm12 0V63.4l-3.2 2.8v-3l3.2-2.9h2.8V76H274Z"],
                        ["stroke", "#FFF", "d", "M1.5 84.5h50v50h-50zm50-50h50v50h-50zm0 50h50v50h-50zm0 50h50v50h-50zm-50 0V177c0 4.1 3.4 7.5 7.5 7.5h42.5v-50h-50Zm150-100h50v50h-50zm0 50h50v50h-50zm50 50h50v50h-50zm50 0v50H294c4.1 0 7.5-3.4 7.5-7.5v-42.5h-50Zm-150 0h50v50h-50zm50 0h50v50h-50z"],
                        ["stroke", "#F88C31", "d", "M1.5 84.5h50v-50H9A7.5 7.5 0 0 0 1.5 42v42.5Zm100-50h50v50h-50zm0 50h50v50h-50zm100-50h50v50h-50zm0 50h50v50h-50zm50-50v50h50V42c0-4.1-3.4-7.5-7.5-7.5h-42.5Zm0 50h50v50h-50z"],
                        ["xmlns", "http://www.w3.org/2000/svg", "fill", "#FFF", "dominant-baseline", "central", "font-size", "12", "text-anchor", "middle", "transform", "translate(227 147)"],
                        ["id", "paytable-odd", "x", "0", "y", "11"],
                        ["fill", "#FFF", "font-size", "12", "transform", "translate(264 152)"],
                        ["x", ".7", "y", "11"],
                        ["xmlns", "http://www.w3.org/2000/svg", "fill", "#FFF", "dominant-baseline", "central", "font-size", "12", "text-anchor", "middle", "transform", "translate(76.5 147)"],
                        ["id", "paytable-even", "x", "0", "y", "11"],
                        ["fill", "#FFF", "font-size", "12", "transform", "translate(17 152)"],
                        ["x", ".1", "y", "11"],
                        ["fill", "#F88C31", "fill-rule", "nonzero", "d", "M125 168h3v40h-3z"],
                        ["fill", "#F88C31", "fill-rule", "nonzero", "d", "M122 166h9v9h-9zm54 2h3v40h-3zm-26 39h3v10h-3z"],
                        ["fill", "#F88C31", "fill-rule", "nonzero", "d", "M173 166h9v9h-9zM26 17h3v40h-3z"],
                        ["fill", "#F88C31", "fill-rule", "nonzero", "d", "M23 49h9v9h-9zm102-32h3v70h-3z"],
                        ["fill", "#F88C31", "fill-rule", "nonzero", "d", "M122 79h9v9h-9zm128-62h3v70h-3z"],
                        ["fill", "#F88C31", "fill-rule", "nonzero", "d", "M247 79h9v9h-9zm-22 89h3v40h-3z"],
                        ["fill", "#F88C31", "fill-rule", "nonzero", "d", "M222 166h9v9h-9z"],
                        ["fill", "#F88C31", "fill-rule", "nonzero"],
                        ["d", "M26 168h3v50h-3z"],
                        ["d", "M23 166h9v9h-9z"],
                        ["d", "M274 168h3v50h-3z"],
                        ["d", "M271 166h9v9h-9z"],
                        ["fill", "#F88C31", "fill-rule", "nonzero", "d", "M75 168h3v40h-3z"],
                        ["fill", "#F88C31", "fill-rule", "nonzero", "d", "M72 166h9v9h-9zm3 39h153v3H75z"],
                        [1, "num1"],
                        [1, "num2"],
                        [1, "num3"],
                        [1, "num4"],
                        [1, "num5"],
                        [1, "num6"]
                    ],
                    template: function(i, n) {
                        1 & i && t.YNc(0, K, 82, 21, "ng-container", 0)
                    },
                    directives: [M.KI],
                    pipes: [Q.q],
                    styles: [".paytable-svg[_ngcontent-%COMP%]{position:relative;display:flex;justify-content:center;align-items:center;height:240px;width:300px;color:#f68b31}.paytable-svg[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:100%;height:100%}.paytable-svg[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{position:absolute}.paytable-svg[_ngcontent-%COMP%]   div.num1[_ngcontent-%COMP%]{left:10px;top:0}.paytable-svg[_ngcontent-%COMP%]   div.num2[_ngcontent-%COMP%]{left:108px;top:0}.paytable-svg[_ngcontent-%COMP%]   div.num3[_ngcontent-%COMP%]{right:32px;top:0}.paytable-svg[_ngcontent-%COMP%]   div.num4[_ngcontent-%COMP%]{left:10px;bottom:0}.paytable-svg[_ngcontent-%COMP%]   div.num5[_ngcontent-%COMP%]{left:130px;bottom:0}.paytable-svg[_ngcontent-%COMP%]   div.num6[_ngcontent-%COMP%]{right:10px;bottom:0}"]
                }), o
            })();
            var E = l(8784),
                X = l(8855);
            const tt = ["canvas"];

            function et(o, e) {
                if (1 & o) {
                    const i = t.EpF();
                    t.TgZ(0, "div", 5), t.TgZ(1, "div", 6), t.TgZ(2, "span", 7), t._uU(3), t.qZA(), t.TgZ(4, "span", 8), t._uU(5), t.ALo(6, "decimalCurrency"), t.qZA(), t.qZA(), t.TgZ(7, "button", 9), t.NdJ("click", function() {
                        return t.CHM(i), t.oxw().onPaytable()
                    }), t._uU(8), t.qZA(), t.qZA()
                }
                if (2 & o) {
                    const i = e.$implicit,
                        n = t.oxw();
                    t.xp6(3), t.hij("", i("shared.Bet"), ":"), t.xp6(2), t.AsE(" ", t.lcZ(6, 5, n.betInMoneyEquivalent), " ", n.config.currency, " "), t.xp6(2), t.Q6J("disabled", n.disabled), t.xp6(1), t.hij(" ", i("shared.Paytable"), " ")
                }
            }

            function it(o, e) {
                if (1 & o) {
                    const i = t.EpF();
                    t.TgZ(0, "div", 10), t.TgZ(1, "button", 11), t.NdJ("click", function() {
                        return t.CHM(i), t.oxw().onUndo()
                    }), t._UZ(2, "svg-icon", 12), t.TgZ(3, "span", 13), t._uU(4), t.qZA(), t.qZA(), t.TgZ(5, "button", 14), t.NdJ("click", function() {
                        return t.CHM(i), t.oxw().onClear()
                    }), t._UZ(6, "svg-icon", 15), t.TgZ(7, "span", 13), t._uU(8), t.qZA(), t.qZA(), t.TgZ(9, "button", 16), t.NdJ("click", function() {
                        return t.CHM(i), t.oxw().onReBet()
                    }), t._UZ(10, "svg-icon", 17), t.TgZ(11, "span", 13), t._uU(12), t.qZA(), t.qZA(), t.qZA()
                }
                if (2 & o) {
                    const i = e.$implicit,
                        n = t.oxw();
                    t.xp6(1), t.Q6J("disabled", n.disabled || 0 === n.totalBet), t.xp6(3), t.hij(" ", i("shared.Back"), " "), t.xp6(1), t.Q6J("disabled", n.disabled || 0 === n.totalBet), t.xp6(3), t.hij(" ", i("shared.Clear"), " "), t.xp6(1), t.Q6J("disabled", n.disabled || !n.hasReBet), t.xp6(3), t.hij(" ", i("shared.Rebet"), " ")
                }
            }
            let C = class {
                constructor(e, i, n, a, s, h) {
                    this.zone = e, this.betControls = i, this.modal = n, this.sound = a, this.translocoService = s, this.coreService = h, this.disabled = !1, this.totalBet = 0, this.hasReBet = !1
                }
                ngOnInit() {
                    !this.isMiniRouletteGame || (this.board = new W(this.canvas.nativeElement, this.zone, this.config, this.gameConfig, this.translocoService), this.board.events$.pipe((0, p.t)(this)).subscribe(e => {
                        "onAddChip" === e.type && (this.sound.playSound(g.pD.rouletteSetChip), this.updateTotalBet())
                    }), this.betControls.onAction$.pipe((0, B.h)(e => e.name == u.w.RouletteChips), (0, p.t)(this)).subscribe(e => {
                        this.board.updateCurrentChipCost(e.data)
                    }))
                }
                get isMiniRouletteGame() {
                    return this.coreService.config.activeGame === R.R.MiniRoulette
                }
                setResult(e) {
                    this.hasReBet = !0, this.board.chipManager.createReBet(), this.board.chipManager.clearLost(e.number), this.board.highlightCell(e.number), this.updateTotalBet()
                }
                onClear() {
                    this.disabled || 0 == this.totalBet || (this.board.chipManager.clearAllChip(), this.sound.playSound(g.pD.rouletteSmallButtons), this.updateTotalBet(), this.board.manualUpdate())
                }
                onUndo() {
                    this.disabled || 0 == this.totalBet || (this.board.chipManager.undoChip(), this.sound.playSound(g.pD.rouletteSmallButtons), this.updateTotalBet(), this.board.manualUpdate())
                }
                onReBet() {
                    this.disabled || !this.hasReBet || (this.board.chipManager.clearAllChip(), this.board.chipManager.reBetChip(), this.sound.playSound(g.pD.rouletteSmallButtons), this.updateTotalBet(), this.board.manualUpdate(), this.hasReBet = !1)
                }
                onPaytable() {
                    this.modal.open(k, {
                        centered: !0
                    })
                }
                updateTotalBet() {
                    this.totalBet = this.board.chipManager.totalBet, +this.betInMoneyEquivalent >= this.config.minBet ? this.betControls.enable([u.w.RouletteSpin]) : this.betControls.disable([u.w.RouletteSpin])
                }
                get betInMoneyEquivalent() {
                    return w.t.mul(this.totalBet, this.gameConfig.chipEquals).toDP(this.config.betPrecision, w.t.ROUND_DOWN).toNumber()
                }
                ngOnDestroy() {
                    this.board && this.board.destroy()
                }
            };
            C.\u0275fac = function(e) {
                return new(e || C)(t.Y36(t.R0b), t.Y36(E.l), t.Y36(j.FF), t.Y36(g.yu), t.Y36(M.Vn), t.Y36(_.p))
            }, C.\u0275cmp = t.Xpm({
                type: C,
                selectors: [
                    ["app-board"]
                ],
                viewQuery: function(e, i) {
                    if (1 & e && t.Gf(tt, 7), 2 & e) {
                        let n;
                        t.iGM(n = t.CRH()) && (i.canvas = n.first)
                    }
                },
                inputs: {
                    config: "config",
                    gameConfig: "gameConfig",
                    disabled: "disabled"
                },
                decls: 5,
                vars: 2,
                consts: [
                    [1, "board", "px-1", "px-md-0"],
                    ["class", "d-flex", 4, "transloco"],
                    [1, "d-block", 2, "border-radius", "8px"],
                    ["canvas", ""],
                    ["class", "d-flex mt-1", 4, "transloco"],
                    [1, "d-flex"],
                    [1, "total-bet"],
                    [1, "label", "gui-text"],
                    [1, "text-white", "ml-1", "font-weight-bold"],
                    [1, "btn", "btn-sm", "p-0", "ml-auto", "btn-paytable", 3, "disabled", "click"],
                    [1, "d-flex", "mt-1"],
                    [1, "btn", "btn-game", 3, "disabled", "click"],
                    ["src", "assets/icons/icon-undo.svg"],
                    [1, "ml-1"],
                    [1, "btn", "btn-game", "ml-1", 3, "disabled", "click"],
                    ["src", "assets/icons/icon-close.svg"],
                    [1, "btn", "btn-game", "btn-game_big", "ml-auto", 3, "disabled", "click"],
                    ["src", "assets/icons/icon-rebet.svg"]
                ],
                template: function(e, i) {
                    1 & e && (t.TgZ(0, "div", 0), t.YNc(1, et, 9, 7, "div", 1), t._UZ(2, "canvas", 2, 3), t.YNc(4, it, 13, 6, "div", 4), t.qZA()), 2 & e && (t.xp6(2), t.ekj("disabled", i.disabled))
                },
                directives: [M.KI, P.bk],
                pipes: [X.P],
                styles: [".board[_ngcontent-%COMP%]{display:flex;flex-direction:column}@media (max-width: 991.98px){.board[_ngcontent-%COMP%]{width:85%;margin-left:auto;margin-right:auto}}.board[_ngcontent-%COMP%]   .btn-paytable[_ngcontent-%COMP%]{text-decoration:underline}.board[_ngcontent-%COMP%]   .total-bet[_ngcontent-%COMP%], .board[_ngcontent-%COMP%]   .btn-paytable[_ngcontent-%COMP%]{font-size:12px;color:#fff;opacity:.8}.board[_ngcontent-%COMP%]   .total-bet[_ngcontent-%COMP%]:hover, .board[_ngcontent-%COMP%]   .btn-paytable[_ngcontent-%COMP%]:hover{opacity:1}.board[_ngcontent-%COMP%]   .btn-game[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;max-width:120px;width:auto;height:auto;font-size:12px;padding:2px 8px}.board[_ngcontent-%COMP%]   .btn-game_big[_ngcontent-%COMP%]{max-width:140px;width:auto;height:auto;line-height:1.2;padding:2px 8px}.board[_ngcontent-%COMP%]   canvas[_ngcontent-%COMP%]{max-width:360px}@media (max-width: 991.98px){.board[_ngcontent-%COMP%]   canvas[_ngcontent-%COMP%]{height:auto;width:100%;max-width:345px}}.board[_ngcontent-%COMP%]   canvas.disabled[_ngcontent-%COMP%]{pointer-events:none}"]
            }), C = (0, U.gn)([(0, p.c)()], C);
            class nt extends c.jyi {
                constructor() {
                    super(), this.anchor.set(.5, .5), this.sprite = new c.jyi(c.xEZ.from("mr_wheel_ball")), this.sprite.anchor.set(.5, .5), this.sprite.y = -140, this.widthBall = this.sprite.width, this.heightBall = this.sprite.height, this.addChild(this.sprite)
                }
                reset() {
                    this.sprite.width = this.widthBall, this.sprite.height = this.heightBall, this.sprite.y = -140
                }
                calcScaledBounds(e = 1) {
                    return {
                        width: this.widthBall * e,
                        height: this.heightBall * e
                    }
                }
            }
            class st extends c.W20 {
                constructor() {
                    super(), this.highlights = {}, this.number2degree = a => 30 * [6, 12, 2, 8, 7, 3, 11, 1, 9, 5, 4, 10].indexOf(a) + 16 + function at(o, e) {
                        return Math.floor(Math.random() * (e - o + 1) + o)
                    }(-5, 5);
                    const e = new c.jyi(c.xEZ.from("mr_wheel_colors"));
                    e.anchor.set(.5, .5), this.addChild(e), this.highlights = this.createHighlights();
                    const i = new c.jyi(c.xEZ.from("mr_wheel_numbers"));
                    i.anchor.set(.5, .5), this.addChild(i);
                    const n = new c.jyi(c.xEZ.from("mr_wheel_bg_top"));
                    n.anchor.set(.5, .5), this.addChild(n), this.ball = new nt, this.ball.visible = !1, this.addChild(this.ball), m.J.tween(this, 10, {
                        angle: -360,
                        repeat: -1,
                        ease: "none"
                    }), this.width = 314, this.height = 314
                }
                spin(e, i) {
                    this.ball.visible = !0, this.ball.angle = 0, this.hideAllHighlights(), this.ball.reset();
                    const a = this.number2degree(e);
                    m.J.tween(this.ball, 3, {
                        angle: 1080 + a,
                        repeat: 0,
                        ease: "sine.out"
                    }).then(() => {
                        m.J.tween(this.getHighlight(e), .1, {
                            alpha: 1
                        }), i()
                    });
                    const {
                        width: h,
                        height: r
                    } = this.ball.calcScaledBounds(.9);
                    m.J.tween(this.ball.sprite, 2, {
                        y: -78,
                        width: h,
                        height: r,
                        repeat: 0,
                        delay: 2,
                        ease: "bounce.out"
                    })
                }
                createHighlights() {
                    const e = {};
                    for (let i = 1; i <= 12; i++) {
                        const n = new c.jyi(c.xEZ.from(`mr_wheel_highlight_${i}`));
                        n.anchor.set(.5, .5);
                        const a = N[`highlight${i}`];
                        n.x = a.x, n.y = a.y, n.alpha = 0, this.addChild(n), e[`highlight${i}`] = n
                    }
                    return e
                }
                getHighlight(e) {
                    return this.highlights[`highlight${e}`]
                }
                hideAllHighlights() {
                    Object.values(this.highlights).forEach(e => e.alpha = 0)
                }
            }
            class ot extends z.f {
                constructor(e, i) {
                    super(e, i, !0, {
                        width: 340,
                        height: 340,
                        autoDensity: !1
                    }), this.createBg(), this.wheel = new st, this.wheel.x = this.appWidth / 2, this.wheel.y = this.appHeight / 2, this.stage.addChild(this.wheel)
                }
                spin(e) {
                    this.wheel.spin(e.number, () => {
                        this.emitEvent("onCompleteSpin", e)
                    })
                }
                createBg() {
                    const e = new c.jyi(c.xEZ.from("mr_wheel_bg"));
                    e.anchor.set(.5, .5), e.width = 340, e.height = 340, this.stage.addChild(e), e.x = this.appWidth / 2, e.y = this.appHeight / 2
                }
                destroy() {
                    super.destroy()
                }
            }
            var lt = l(8269),
                ht = l(6064),
                rt = l(2983),
                ct = l(9798),
                dt = l(4219),
                pt = l(3031);
            const gt = ["canvas"];
            let y = class {
                constructor(e, i, n, a, s, h, r, d, vt, Ct) {
                    this.core = e, this.connector = i, this.betControls = n, this.zone = a, this.disableBtnBetService = s, this.sound = h, this.ifcSeenderService = r, this.maxWinService = d, this.toast = vt, this.translocoService = Ct
                }
                ngOnInit() {
                    !this.isMiniRouletteGame || (this.maxWinService.profit = 0, this.setup(), this.betControls.hide([u.w.BetInput]), this.core.freeBets.onResetFreeBet$.pipe((0, p.t)(this)).subscribe(() => {
                        this.betControls.enableAll(), this.disabled(!1), this.core.invokeEndRound()
                    }))
                }
                get isMiniRouletteGame() {
                    return this.core.config.activeGame === R.R.MiniRoulette
                }
                get gameConfig() {
                    return this.core.gameConfig
                }
                get config() {
                    return this.core.config
                }
                setup() {
                    this.betControls.show([u.w.RouletteChips, u.w.RouletteSpin]), this.betControls.disable([u.w.RouletteSpin]), this.wheel = new ot(this.canvas.nativeElement, this.zone), this.wheel.events$.pipe((0, D.z)((0, B.h)(e => "onCompleteSpin" === e.type)), (0, p.t)(this)).subscribe(e => {
                        this.ifcSeenderService.endRound(e.data), this.core.invokeEndRound(e.data), this.disabled(!1), this.boardComponent.setResult(e.data), e.data.win && this.sound.playSound(g.pD.win)
                    }), this.betControls.onAction$.pipe((0, B.h)(e => e.name == u.w.RouletteSpin), (0, p.t)(this)).subscribe(() => {
                        this.makeSpin()
                    }), this.connector.response(Y.E.Bet).pipe((0, p.t)(this)).subscribe(e => {
                        if (this.ifcSeenderService.startRound(e), 200 !== e.code) return this.betControls.errorBetResponse(), void this.disabled(!1);
                        this.disableBtnBetService.initDisable(), this.wheel.spin(e), this.sound.playSound(g.pD.rouletteSpin)
                    }), setTimeout(() => {
                        this.boardComponent.board.chipManager.updateChips$.pipe((0, p.t)(this)).subscribe(() => {
                            this.calcMaxWin(this.boardComponent.board.chipManager.getAllChip())
                        })
                    }, 0)
                }
                makeSpin() {
                    this.disabled(!0);
                    const e = JSON.stringify(this.boardComponent.board.chipManager.getAllChip()),
                        i = +this.boardComponent.betInMoneyEquivalent;
                    if (this.betControls.betAmount = i, this.core.isBalanceInsufficientForBet(this.betControls.betAmount)) return this.disabled(!1), void this.toast.showError(this.translocoService.translate("shared.balance_not_enough"));
                    this.ifcSeenderService.makeBet(i);
                    const a = this.core.invokeStartRound(i, {
                        chips: e
                    });
                    this.connector.request(I.T.Bet, a)
                }
                disabled(e) {
                    e ? (this.betControls.disableAll(), this.boardComponent.disabled = !0) : (this.betControls.enableAll(), this.boardComponent.disabled = !1)
                }
                calcMaxWin(e) {
                    if (!e || 0 === Object.keys(e).length && e.constructor === Object) this.maxWinService.profit = 0;
                    else
                        for (let i = 1; i < 13; i++) {
                            let n = 0;
                            for (const a in e)
                                if (Object.prototype.hasOwnProperty.call(e, a)) {
                                    const s = e[a];
                                    0 === a.indexOf("n") && +a.slice(1) === i && (n = this.calcAllValue(n, s, this.gameConfig.payTable.numAmount1)), 0 === a.indexOf("s") && x.sectors.s.map((r, d) => r.includes(i) ? d : -1).filter(r => -1 !== r).includes(+a.slice(1)) && (n = this.calcAllValue(n, s, this.gameConfig.payTable.numAmount4)), 0 === a.indexOf("h") && !a.includes("half") && x.sectors.h[+a.slice(1)].includes(i) && (n = this.calcAllValue(n, s, this.gameConfig.payTable.numAmount2)), 0 === a.indexOf("v") && x.sectors.v[+a.slice(1)].includes(i) && (n = this.calcAllValue(n, s, this.gameConfig.payTable.numAmount2)), (a.includes("half") || a.includes("even") || a.includes("black") || a.includes("red") || a.includes("odd")) && x.buttons[a].includes(i) && (n = this.calcAllValue(n, s, this.gameConfig.payTable.numAmount6))
                                }
                            if (this.maxWinService.profit = n, n > this.config.maxUserWin) break
                        }
                }
                calcAllValue(e, i, n) {
                    return new w.t(i).times(this.gameConfig.chipEquals).times(n).plus(e).toDP(this.config.betPrecision, w.t.ROUND_DOWN).toNumber()
                }
                ngOnDestroy() {
                    this.wheel && this.wheel.destroy()
                }
            };
            y.\u0275fac = function(e) {
                return new(e || y)(t.Y36(_.p), t.Y36(lt.v), t.Y36(E.l), t.Y36(t.R0b), t.Y36(ht.i), t.Y36(g.yu), t.Y36(rt.S), t.Y36(ct.a), t.Y36(dt.k), t.Y36(M.Vn))
            }, y.\u0275cmp = t.Xpm({
                type: y,
                selectors: [
                    ["app-mini-roulette"]
                ],
                viewQuery: function(e, i) {
                    if (1 & e && (t.Gf(C, 7), t.Gf(gt, 7)), 2 & e) {
                        let n;
                        t.iGM(n = t.CRH()) && (i.boardComponent = n.first), t.iGM(n = t.CRH()) && (i.canvas = n.first)
                    }
                },
                decls: 7,
                vars: 2,
                consts: [
                    [1, "mini-roulette-wrapper"],
                    [1, "max-win"],
                    [1, "mini-roulette-canvas", "mr-0", "mr-md-3", "p-1", "p-md-0"],
                    [1, ""],
                    ["canvas", ""],
                    [1, "board-wrapper", "mt-2", "mt-md-0"],
                    [3, "config", "gameConfig"]
                ],
                template: function(e, i) {
                    1 & e && (t.TgZ(0, "div", 0), t._UZ(1, "app-max-win", 1), t.TgZ(2, "div", 2), t._UZ(3, "canvas", 3, 4), t.qZA(), t.TgZ(5, "div", 5), t._UZ(6, "app-board", 6), t.qZA(), t.qZA()), 2 & e && (t.xp6(6), t.Q6J("config", i.config)("gameConfig", i.gameConfig))
                },
                directives: [pt.y, C],
                styles: [".mini-roulette-wrapper[_ngcontent-%COMP%]{position:relative;font-size:18px;height:100%;max-width:720px;display:flex;align-items:center;justify-content:center;flex-direction:column;margin-left:auto;margin-right:auto}@media (min-width: 768px){.mini-roulette-wrapper[_ngcontent-%COMP%]{flex-direction:row}}.mini-roulette-wrapper[_ngcontent-%COMP%]   .max-win[_ngcontent-%COMP%]{position:absolute;top:6px;right:4px}@media (min-width: 768px){.mini-roulette-wrapper[_ngcontent-%COMP%]   .max-win[_ngcontent-%COMP%]{display:none}}.mini-roulette-wrapper[_ngcontent-%COMP%]   .mini-roulette-canvas[_ngcontent-%COMP%]{position:relative;flex-shrink:0;height:45%}@media (min-width: 768px){.mini-roulette-wrapper[_ngcontent-%COMP%]   .mini-roulette-canvas[_ngcontent-%COMP%]{max-height:100%;height:340px}}@media (max-width: 767.98px){.mini-roulette-wrapper[_ngcontent-%COMP%]   .mini-roulette-canvas[_ngcontent-%COMP%]   canvas[_ngcontent-%COMP%]{margin-left:auto;margin-right:auto!important}}.mini-roulette-wrapper[_ngcontent-%COMP%]   .mini-roulette-canvas[_ngcontent-%COMP%]   canvas[_ngcontent-%COMP%]{display:block;max-width:100%;max-height:100%}.mini-roulette-wrapper[_ngcontent-%COMP%]   .board-wrapper[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center}@media (max-width: 991.98px){.mini-roulette-wrapper[_ngcontent-%COMP%]   .board-wrapper[_ngcontent-%COMP%]{height:auto}}"]
            }), y = (0, U.gn)([(0, p.c)()], y);
            var ut = l(4364),
                mt = l(3904);
            const ft = [{
                path: "",
                component: y
            }];
            let bt = (() => {
                class o {}
                return o.\u0275fac = function(i) {
                    return new(i || o)
                }, o.\u0275mod = t.oAB({
                    type: o
                }), o.\u0275inj = t.cJS({
                    imports: [
                        [F.ez, H.Bz.forChild(ft), P._J, V.p, M.y4, ut.D, mt.T]
                    ]
                }), o
            })()
        }
    }
]);