"use strict";
(self.webpackChunkng_turbo_games = self.webpackChunkng_turbo_games || []).push([
    [794], {
        8794: (z, P, r) => {
            r.r(P), r.d(P, {
                KenoModule: () => J
            });
            var f = r(9808),
                x = r(4996),
                h = r(6352),
                v = r(7303),
                C = r(655),
                p = r(4987),
                w = r(9300),
                y = r(8044),
                A = r(4946),
                b = r(4750),
                c = r(2398),
                e = r(7587),
                g = r(7258),
                m = r(4431),
                _ = r(8784),
                k = r(2821),
                Z = r(9798),
                B = r(3031),
                D = r(1560);

            function T(i, t) {
                if (1 & i && (e.TgZ(0, "div", 17), e.TgZ(1, "span"), e._uU(2), e.qZA(), e.qZA()), 2 & i) {
                    const n = e.oxw().$implicit,
                        o = e.oxw();
                    e.xp6(2), e.hij(" ", o.disabled ? "" : n("shared.PICK-NUMBERS-FOR-START"), " ")
                }
            }

            function R(i, t) {
                if (1 & i) {
                    const n = e.EpF();
                    e.TgZ(0, "div", 18), e.TgZ(1, "div", 19), e.TgZ(2, "div", 20), e.NdJ("click", function() {
                        const d = e.CHM(n).$implicit;
                        return e.oxw(2).onSelectNumber(d)
                    }), e._uU(3), e.qZA(), e.qZA(), e.qZA()
                }
                if (2 & i) {
                    const n = t.$implicit,
                        o = e.oxw(2);
                    e.xp6(2), e.ekj("selected", n.selected)("result", n.result)("hit", n.hit)("animate", o.animation), e.xp6(1), e.hij(" ", n.number, " ")
                }
            }
            const N = function(i) {
                return {
                    "max-coef": i
                }
            };

            function K(i, t) {
                if (1 & i && (e.TgZ(0, "div", 21), e.TgZ(1, "span", 22), e._uU(2), e.qZA(), e.TgZ(3, "span", 23), e._uU(4), e.ALo(5, "decimalMultiplier"), e.qZA(), e.qZA()), 2 & i) {
                    const n = t.$implicit;
                    e.Q6J("ngClass", e.VKq(7, N, n.viewValue < n.value)), e.xp6(1), e.ekj("hit", n.hit), e.xp6(1), e.Oqu(n.num), e.xp6(2), e.hij("", e.lcZ(5, 5, n.viewValue), "x")
                }
            }

            function F(i, t) {
                if (1 & i) {
                    const n = e.EpF();
                    e.TgZ(0, "div", 1), e.TgZ(1, "div", 2), e.TgZ(2, "div", 3), e.YNc(3, T, 3, 1, "div", 4), e._UZ(4, "app-max-win", 5), e.qZA(), e.TgZ(5, "div", 6), e.TgZ(6, "div", 7), e.YNc(7, R, 4, 9, "div", 8), e.qZA(), e.TgZ(8, "div", 9), e.TgZ(9, "div", 10), e.YNc(10, K, 6, 9, "div", 11), e.qZA(), e.qZA(), e.qZA(), e.TgZ(11, "div", 12), e.TgZ(12, "button", 13), e.NdJ("click", function() {
                        return e.CHM(n), e.oxw().onPickRandomly()
                    }), e.TgZ(13, "span", 14), e._uU(14), e.qZA(), e.qZA(), e.TgZ(15, "button", 15), e.NdJ("click", function() {
                        return e.CHM(n), e.oxw().onClear()
                    }), e.TgZ(16, "span", 16), e._uU(17), e.qZA(), e.qZA(), e.qZA(), e.qZA(), e.qZA()
                }
                if (2 & i) {
                    const n = t.$implicit,
                        o = e.oxw();
                    e.xp6(3), e.Q6J("ngIf", !o.factors.length), e.xp6(4), e.Q6J("ngForOf", o.grid), e.xp6(3), e.Q6J("ngForOf", o.factors), e.xp6(2), e.Q6J("disabled", o.disabled), e.xp6(2), e.hij(" ", n("shared.RANDOM"), " "), e.xp6(1), e.Q6J("disabled", o.disabled || 0 === o.selectedCount), e.xp6(2), e.hij(" ", n("shared.Clear"), " ")
                }
            }
            let l = class {
                constructor(t, n, o, s) {
                    this.sound = t, this.betControls = n, this.core = o, this.maxWinService = s, this.grid = [], this.factors = [], this.disabled = !1, this.animation = !0, this.factorConfig = [], this.whenChangingSelected = new e.vpe, this.byResultDrawCompleted = new e.vpe, this.timeOuts = []
                }
                ngOnInit() {
                    for (let t = 0; t < 36; t++) this.grid.push({
                        number: t + 1,
                        selected: !1,
                        result: !1,
                        hit: !1
                    });
                    this.changeSelected(), this.betControls.onUpdateBetAmount$.pipe((0, p.t)(this)).subscribe(() => {
                        this.updateProfit()
                    }), this.core.freeBets.onActivate$.pipe((0, p.t)(this)).subscribe(() => {
                        this.updateProfit()
                    })
                }
                onSelectNumber(t) {
                    if (this.disabled) return;
                    this.grid.filter(s => !0 === s.result).length > 0 && this.resetAllItems();
                    const n = t.selected,
                        o = this.selectedCount;
                    o < 10 || 10 === o && n ? (t.selected = !n, n || this.sound.playSound(m.pD.kenoSelectNum), this.changeSelected()) : this.sound.playSound(m.pD.kenoDisabledNum)
                }
                onPickRandomly() {
                    this.resetAllItems();
                    const t = function S(i) {
                        for (let t = i.length - 1; t > 0; t--) {
                            const n = Math.floor(Math.random() * (t + 1));
                            [i[t], i[n]] = [i[n], i[t]]
                        }
                        return i
                    }(Array(36).fill(0).map((n, o) => o + 1)).splice(0, 10);
                    this.grid.forEach(n => {
                        t.includes(n.number) && (n.selected = !0)
                    }), this.changeSelected(), this.sound.playSound(m.pD.kenoSelectNum)
                }
                onClear() {
                    this.sound.playSound(m.pD.buttonClick), this.resetAllItems(), this.changeSelected()
                }
                resetHitAndResult() {
                    this.resetAllItems("hit"), this.resetAllItems("result"), this.updateFactors()
                }
                setResult(t) {
                    const n = t.numbers;
                    let s = 0;
                    this.grid.forEach(a => {
                        if (n.includes(a.number)) {
                            const H = setTimeout(() => {
                                a.result = !0, a.selected && (a.hit = !0, this.sound.playSound(m.pD.kenoHitNum), this.updateHitFactor())
                            }, !1 === this.animation ? 0 : 150 * s);
                            this.timeOuts.push(H), s++
                        }
                    }), setTimeout(() => {
                        this.sound.playSound(m.pD.kenoResult), this.byResultDrawCompleted.emit(t)
                    }, !1 === this.animation ? 500 : 150 * s)
                }
                get selectedCount() {
                    return this.grid.filter(t => !0 === t.selected).length
                }
                get selectedNumbers() {
                    return this.grid.filter(t => !0 === t.selected).map(t => t.number)
                }
                updateFactors() {
                    this.factors = [];
                    const t = this.factorConfig[this.selectedCount - 1];
                    t && t.forEach((n, o) => {
                        this.factors.push({
                            num: o + 1,
                            value: n,
                            hit: !1,
                            viewValue: n
                        })
                    }), this.updateProfit()
                }
                updateHitFactor() {
                    const t = this.grid.filter(n => n.hit).length;
                    t > 0 && (this.factors[t - 1].hit = !0)
                }
                resetAllItems(t = null) {
                    this.grid.forEach(n => {
                        null != t ? n[t] = !1 : (n.hit = !1, n.selected = !1, n.result = !1)
                    })
                }
                changeSelected() {
                    this.updateFactors(), this.whenChangingSelected.emit(this.selectedNumbers)
                }
                updateProfit() {
                    var t, n;
                    const o = null === (n = null === (t = this.factors) || void 0 === t ? void 0 : t[this.factors.length - 1]) || void 0 === n ? void 0 : n.value;
                    if (o) {
                        if (this.core.freeBets.activeFreeBet) return void(this.maxWinService.profit = g.t.mul(this.core.freeBets.activeFreeBet.betAmount, o).sub(this.core.freeBets.activeFreeBet.betAmount).toDP(this.core.config.betPrecision, g.t.ROUND_DOWN).toNumber());
                        this.maxWinService.profit = g.t.mul(o, this.betControls.betAmount).toDP(this.core.config.betPrecision, g.t.ROUND_DOWN).toNumber()
                    } else this.maxWinService.profit = 0;
                    this.updateCoefMaxWin()
                }
                updateCoefMaxWin() {
                    if (!this.core.config.isMaxWinAm) return;
                    let t = g.t.div(this.core.config.maxUserWin, this.betControls.betAmount).toDP(2, g.t.ROUND_DOWN);
                    this.core.freeBets.activeFreeBet && (t = g.t.div(this.core.config.maxUserWin, this.core.freeBets.activeFreeBet.betAmount).plus(1).toDP(2, g.t.ROUND_DOWN)), this.factors.forEach(n => {
                        n.viewValue = t.lt(n.value) ? t.toNumber() : n.value
                    })
                }
                ngOnDestroy() {}
            };
            l.\u0275fac = function(t) {
                return new(t || l)(e.Y36(m.yu), e.Y36(_.l), e.Y36(k.p), e.Y36(Z.a))
            }, l.\u0275cmp = e.Xpm({
                type: l,
                selectors: [
                    ["app-keno-grid"]
                ],
                inputs: {
                    disabled: "disabled",
                    animation: "animation",
                    factorConfig: "factorConfig"
                },
                outputs: {
                    whenChangingSelected: "whenChangingSelected",
                    byResultDrawCompleted: "byResultDrawCompleted"
                },
                decls: 1,
                vars: 0,
                consts: [
                    ["class", "keno-wrapper", 4, "transloco"],
                    [1, "keno-wrapper"],
                    [1, "keno-game"],
                    [1, "keno-header", "d-flex", "flex-column", "align-items-end"],
                    ["class", "text-success mb-1", 4, "ngIf"],
                    [1, "max-win", "p-1"],
                    [1, "keno-grid", "px-1", "px-md-0"],
                    [1, "keno-grid-numbers", "row", "no-gutters"],
                    ["class", "col-2 d-flex justify-content-center align-items-center", 4, "ngFor", "ngForOf"],
                    [1, "keno-grid-factors", "pl-1", "pl-md-2"],
                    [1, "grid-factors-col", "pl-1"],
                    ["class", "grid-factor", 3, "ngClass", 4, "ngFor", "ngForOf"],
                    [1, "keno-footer"],
                    [1, "btn", "btn-game", "w-100", "mr-1", 3, "disabled", "click"],
                    [1, "centered-xy"],
                    [1, "btn", "btn-game", "w-100", "ml-1", 3, "disabled", "click"],
                    [1, "centered-xy", "text-uppercase"],
                    [1, "text-success", "mb-1"],
                    [1, "col-2", "d-flex", "justify-content-center", "align-items-center"],
                    [1, "grid-number-wrapper"],
                    [1, "number", 3, "click"],
                    [1, "grid-factor", 3, "ngClass"],
                    [1, "num"],
                    [1, "lbl"]
                ],
                template: function(t, n) {
                    1 & t && e.YNc(0, F, 18, 7, "div", 0)
                },
                directives: [h.KI, f.O5, B.y, f.sg, f.mk],
                pipes: [D.q],
                styles: ['@media (min-width: 768px){.max-win[_ngcontent-%COMP%]{display:none}}.keno-wrapper[_ngcontent-%COMP%]{font-size:18px;height:100%;display:flex;align-items:center;justify-content:center}@media (min-width: 768px){.keno-wrapper[_ngcontent-%COMP%]:after, .keno-wrapper[_ngcontent-%COMP%]:before{content:" ";position:absolute;left:-8px;top:50%;transform:translateY(-50%);width:179px;height:358px;background:url(keno-bg.8f15ce39c9278ad1.svg)}.keno-wrapper[_ngcontent-%COMP%]:before{right:-8px;left:auto;transform:translateY(-50%) rotate(180deg)}}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;justify-content:space-between;padding:2px;z-index:1}@media (min-width: 768px){.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]{justify-content:center}}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-header[_ngcontent-%COMP%]{height:60px}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-header[_ngcontent-%COMP%]   .text-success[_ngcontent-%COMP%]{background-color:#15171969;width:100%;border-radius:12px;display:flex;justify-content:center;align-items:center;height:1.23em}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-header[_ngcontent-%COMP%]   .text-success[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.67em}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]{display:flex}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]{max-width:calc(100vw - 100px);max-height:calc(100vw - 100px)}@media (min-width: 768px){.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]{max-width:18em}}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]   .grid-number-wrapper[_ngcontent-%COMP%]{width:calc((100vw - 120px) / 6);height:calc((100vw - 120px) / 6);max-width:4.5em;max-height:4.5em;padding:.11em}@media (min-width: 768px){.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]   .grid-number-wrapper[_ngcontent-%COMP%]{width:3em;height:3em}}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]   .grid-number-wrapper[_ngcontent-%COMP%]   .number[_ngcontent-%COMP%]{width:100%;height:100%;display:flex;justify-content:center;align-items:center;color:#fff;border-radius:50%;background-image:radial-gradient(circle at 74% 90%,#000,#601034);box-shadow:10px 10px 20px -14px #0a0e1f;position:relative;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;user-select:none}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]   .grid-number-wrapper[_ngcontent-%COMP%]   .number[_ngcontent-%COMP%]:after{content:" ";position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:85%;height:85%;border:2px solid rgba(255,255,255,.3);border-radius:50%}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]   .grid-number-wrapper[_ngcontent-%COMP%]   .number.selected[_ngcontent-%COMP%]{background-image:radial-gradient(circle at 74% 90%,#f294b5,#ffffff);color:#000;font-weight:700}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]   .grid-number-wrapper[_ngcontent-%COMP%]   .number.selected[_ngcontent-%COMP%]:after{border:2px solid rgba(255,0,0,.31)}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]   .grid-number-wrapper[_ngcontent-%COMP%]   .number.result[_ngcontent-%COMP%]{border:2px solid yellow}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]   .grid-number-wrapper[_ngcontent-%COMP%]   .number.hit[_ngcontent-%COMP%]{background-image:radial-gradient(circle at 74% 90%,#fe7302,#fdd606);color:#000;font-weight:700}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-numbers[_ngcontent-%COMP%]   .grid-number-wrapper[_ngcontent-%COMP%]   .number.hit[_ngcontent-%COMP%]:after{border:2px solid #ce6d1b}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]{width:4.5em;display:flex;flex-direction:column;justify-content:center}@media (min-width: 768px){.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]{width:6em}}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]   .grid-factors-col[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column-reverse;justify-content:center;background:transparent;border:1px solid rgba(255,255,255,.2);border-radius:6px}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]   .grid-factors-col[_ngcontent-%COMP%]   .grid-factor[_ngcontent-%COMP%]{display:flex;align-items:center;padding:1px 0}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]   .grid-factors-col[_ngcontent-%COMP%]   .grid-factor[_ngcontent-%COMP%]   .num[_ngcontent-%COMP%]{flex:0 0 1.8em;height:1.8em;border-radius:50%;background:rgba(0,0,0,.3);display:flex;justify-content:center;align-items:center;color:#fff;font-size:.65em;line-height:.45em}@media (min-width: 768px){.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]   .grid-factors-col[_ngcontent-%COMP%]   .grid-factor[_ngcontent-%COMP%]   .num[_ngcontent-%COMP%]{flex:0 0 2.3em;height:2.3em}}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]   .grid-factors-col[_ngcontent-%COMP%]   .grid-factor[_ngcontent-%COMP%]   .num.hit[_ngcontent-%COMP%]{background-image:radial-gradient(circle at 74% 90%,#fe7302,#fdd606);box-shadow:10px 10px 20px -9px #1f0a0f69;color:#000;font-weight:700}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]   .grid-factors-col[_ngcontent-%COMP%]   .grid-factor[_ngcontent-%COMP%]   .lbl[_ngcontent-%COMP%]{color:#fff;font-size:.65em;margin-left:.25em}@media (min-width: 768px){.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]   .grid-factors-col[_ngcontent-%COMP%]   .grid-factor[_ngcontent-%COMP%]   .lbl[_ngcontent-%COMP%]{margin-left:.5em}}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]   .grid-factors-col[_ngcontent-%COMP%]   .grid-factor.max-coef[_ngcontent-%COMP%]   .lbl[_ngcontent-%COMP%]{display:flex;justify-content:center;align-items:center;height:16px;padding:0 3px;border:1px solid #fff;border-radius:100px;background-color:#b32b00}@media (min-width: 768px){.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-grid[_ngcontent-%COMP%]   .keno-grid-factors[_ngcontent-%COMP%]   .grid-factors-col[_ngcontent-%COMP%]   .grid-factor.max-coef[_ngcontent-%COMP%]   .lbl[_ngcontent-%COMP%]{padding:0 6px}}.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-footer[_ngcontent-%COMP%]{padding-top:.5em;display:flex}@media (max-width: 767.98px){.keno-wrapper[_ngcontent-%COMP%]   .keno-game[_ngcontent-%COMP%]   .keno-footer[_ngcontent-%COMP%]{margin-bottom:10px;margin-left:10px;margin-right:10px}}.btn-game[_ngcontent-%COMP%]{height:1.67em}.btn-game[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.77em}']
            }), l = (0, C.gn)([(0, p.c)()], l);
            var U = r(8269),
                Y = r(6064),
                E = r(2983),
                G = r(4219);
            let u = class {
                constructor(t, n, o, s, d, a, M) {
                    this.core = t, this.betControls = n, this.connector = o, this.disableBtnBetService = s, this.ifcSeenderService = d, this.toast = a, this.translocoService = M, this.gridDisabled = !1, this.isBetAutoPlay = !1
                }
                ngOnInit() {
                    this.betControls.show([c.w.Autoplay, c.w.Bet]), this.connector.response(A.E.Bet).pipe((0, p.t)(this)).subscribe(t => {
                        if (this.ifcSeenderService.startRound(t), 200 !== t.code) return this.isBetAutoPlay = !1, this.gridDisabled = !1, void this.betControls.errorBetResponse();
                        this.betResponse(t), this.grid.setResult(t)
                    }), this.betControls.onAction$.pipe((0, w.h)(t => t.name == c.w.Bet || t.name == c.w.Autoplay), (0, p.t)(this)).subscribe(t => {
                        this.isBetAutoPlay = t.name === c.w.Autoplay, this.makeBet()
                    }), this.core.freeBets.onResetFreeBet$.pipe((0, p.t)(this)).subscribe(() => {
                        this.isBetAutoPlay = !1, this.gridDisabled = !1, this.betControls.enableAll(), this.core.invokeEndRound()
                    })
                }
                get gameConfig() {
                    return this.core.gameConfig
                }
                onChangeSelected(t) {
                    t.length ? this.betControls.enable([c.w.Autoplay, c.w.Bet]) : this.betControls.disable([c.w.Autoplay, c.w.Bet])
                }
                makeBet() {
                    if (this.core.isBalanceInsufficientForBet(this.betControls.betAmount)) return this.toast.showError(this.translocoService.translate("shared.balance_not_enough")), void(this.betControls.autoplay.isActive && (this.betControls.autoplayHandler(null), this.betControls.enable([c.w.Autoplay])));
                    if (0 === this.grid.selectedCount) return;
                    this.gridDisabled = !0, this.grid.resetHitAndResult(), this.betControls.disableAll();
                    const t = this.betControls.adjustBet();
                    this.ifcSeenderService.makeBet(t);
                    const o = this.core.invokeStartRound(t, {
                        numbers: this.grid.selectedNumbers
                    });
                    this.connector.request(y.T.Bet, o)
                }
                onResultDrawComplete(t) {
                    return (0, C.mG)(this, void 0, void 0, function*() {
                        yield(0, b.V)(this.core.config.minRoundDurationInMillis), this.ifcSeenderService.endRound(t), this.core.invokeEndRound(t), this.betControls.autoplay.isActive ? (this.core.config.isShowWinAmountUntilNextRound && (yield(0, b.V)(500)), this.makeBet()) : (this.betControls.enableAll(), this.gridDisabled = !1)
                    })
                }
                betResponse(t) {
                    this.disableBtnBetService.initDisable(), this.betControls.onBetResponse({
                        winAmount: t.winAmount,
                        win: t.win,
                        betAmount: t.betAmount
                    }), !this.betControls.autoplay.isActive && this.isBetAutoPlay && this.ifcSeenderService.startAutoplay(!1)
                }
                ngOnDestroy() {}
            };
            u.\u0275fac = function(t) {
                return new(t || u)(e.Y36(k.p), e.Y36(_.l), e.Y36(U.v), e.Y36(Y.i), e.Y36(E.S), e.Y36(G.k), e.Y36(h.Vn))
            }, u.\u0275cmp = e.Xpm({
                type: u,
                selectors: [
                    ["app-keno"]
                ],
                viewQuery: function(t, n) {
                    if (1 & t && e.Gf(l, 7), 2 & t) {
                        let o;
                        e.iGM(o = e.CRH()) && (n.grid = o.first)
                    }
                },
                decls: 1,
                vars: 2,
                consts: [
                    [3, "disabled", "factorConfig", "whenChangingSelected", "byResultDrawCompleted"]
                ],
                template: function(t, n) {
                    1 & t && (e.TgZ(0, "app-keno-grid", 0), e.NdJ("whenChangingSelected", function(s) {
                        return n.onChangeSelected(s)
                    })("byResultDrawCompleted", function(s) {
                        return n.onResultDrawComplete(s)
                    }), e.qZA()), 2 & t && e.Q6J("disabled", n.gridDisabled)("factorConfig", n.gameConfig.grid.factors)
                },
                directives: [l],
                styles: [""]
            }), u = (0, C.gn)([(0, p.c)()], u);
            var I = r(3904);
            const W = [{
                path: "",
                component: u
            }];
            let J = (() => {
                class i {}
                return i.\u0275fac = function(n) {
                    return new(n || i)
                }, i.\u0275mod = e.oAB({
                    type: i
                }), i.\u0275inj = e.cJS({
                    imports: [
                        [f.ez, x.Bz.forChild(W), v.p, h.y4, I.T]
                    ]
                }), i
            })()
        }
    }
]);