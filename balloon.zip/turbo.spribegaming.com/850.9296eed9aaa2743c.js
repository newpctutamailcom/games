"use strict";
(self.webpackChunkng_turbo_games = self.webpackChunkng_turbo_games || []).push([
    [850], {
        1850: (Se, M, l) => {
            l.r(M), l.d(M, {
                BalloonModule: () => he
            });
            var f = l(9808),
                L = l(4996),
                P = l(6352),
                S = l(8248),
                e = l(7587);
            let T = (() => {
                    class i {}
                    return i.\u0275fac = function(o) {
                        return new(o || i)
                    }, i.\u0275mod = e.oAB({
                        type: i
                    }), i.\u0275inj = e.cJS({
                        imports: [
                            [f.ez, S._J]
                        ]
                    }), i
                })(),
                R = (() => {
                    class i {}
                    return i.\u0275fac = function(o) {
                        return new(o || i)
                    }, i.\u0275mod = e.oAB({
                        type: i
                    }), i.\u0275inj = e.cJS({
                        imports: [
                            [f.ez, S._J]
                        ]
                    }), i
                })();
            var h = l(655),
                m = l(4987),
                _ = l(7258),
                Z = l(4128),
                G = l(5963),
                E = l(4049),
                D = l(9646),
                B = l(9300),
                x = l(5698),
                H = l(4825),
                O = l(4004),
                I = l(4482),
                U = l(7886),
                W = l(3269),
                Y = l(2076);
            var y = l(8044),
                w = l(4946),
                p = l(9082),
                a = l(4431),
                N = l(5111),
                b = l(4750),
                u = l(2398),
                n = l(189),
                z = l(8784),
                A = l(2821),
                $ = l(8269),
                k = l(6064),
                j = l(4219),
                K = l(9798),
                q = l(2983),
                Q = l(710),
                r = l(9749),
                X = l(6652),
                ee = l(9150);
            const te = function(i) {
                return {
                    "bonus-game-label--disabled": i
                }
            };

            function ne(i, t) {
                if (1 & i) {
                    const o = e.EpF();
                    e.TgZ(0, "button", 24), e.NdJ("click", function() {
                        return e.CHM(o), e.oxw().onBonusInfoLabelClick()
                    }), e._uU(1, " Bonus Game\n"), e.qZA()
                }
                if (2 & i) {
                    const o = e.oxw();
                    e.Q6J("disabled", o.isBonusGameLabelDisabled)("ngClass", e.VKq(2, te, o.isBonusGameLabelDisabled))
                }
            }
            let oe = (() => {
                    class i {
                        constructor(o, s, c) {
                            this.coreService = o, this.modal = s, this.disableBtnBetService = c, this.tlMain = r.p8.timeline(), this.tlWin = r.p8.timeline(), this.tlAviator = r.p8.timeline(), this.tlComet = r.p8.timeline(), this.tlSatelite = r.p8.timeline(), this.tlUfo = r.p8.timeline(), this.tlTesla = r.p8.timeline(), this.randomLocation = r.p8.utils.random(1, 3, 1)
                        }
                        ngOnChanges(o) {
                            var s, c;
                            !(null === (s = o.status) || void 0 === s ? void 0 : s.isFirstChange()) && o.status && this.updatePlayAnim(o.status.currentValue), !(null === (c = o.winGame) || void 0 === c ? void 0 : c.isFirstChange()) && o.winGame && this.updatePlayAnimCircl()
                        }
                        ngOnInit() {
                            this.createAnim(), r.p8.set(".background__bonus", {
                                autoAlpha: 0
                            })
                        }
                        createAnim() {
                            this.tlAviator.to(".aviator", {
                                backgroundPosition: "-100px 0px",
                                ease: "steps(1)",
                                duration: .3,
                                repeat: -1
                            }, 0).to(".wrap-aviator", {
                                x: "100%",
                                y: "150%",
                                duration: 15,
                                ease: "none"
                            }, 0).pause(), this.tlComet.to(".wrap-comet", {
                                x: "100px",
                                y: "100%",
                                duration: 10,
                                ease: "none"
                            }, 0).pause(), this.tlSatelite.to(".wrap-satelite", {
                                x: "-100%",
                                y: "20%",
                                duration: 10,
                                ease: "none"
                            }, 0).to(".satelite", {
                                rotate: 150,
                                duration: 10,
                                ease: "none"
                            }, 0).pause(), this.tlUfo.to(".wrap-ufo", {
                                x: "100%",
                                y: "25%",
                                duration: 10,
                                ease: "none"
                            }, 0).to(".ufo", {
                                rotation: 12,
                                duration: 1,
                                yoyo: !0,
                                repeat: -1,
                                ease: "power1.inOut"
                            }, 0).to(".ufo", {
                                rotation: -12,
                                duration: 1,
                                yoyo: !0,
                                repeat: -1,
                                ease: "power1.inOut",
                                delay: 1
                            }, 0).pause(), this.tlTesla.to(".wrap-tesla", {
                                y: "100%",
                                x: "-100%",
                                duration: 20,
                                ease: "none"
                            }, 0).pause(), this.tlWin.to(".rays", {
                                duration: n.L3.background.speed.rays,
                                rotation: 360,
                                ease: "none"
                            }, 0).to(".rays", {
                                duration: n.L3.delay.beforeEndGameSecond / 1e3 / 2,
                                opacity: .2
                            }, 0).to(".rays", {
                                duration: n.L3.delay.beforeEndGameSecond / 1e3 / 2,
                                opacity: 0
                            }, n.L3.delay.beforeEndGameSecond / 1e3 / 2).pause(), this.tlMain.to(".ground", {
                                duration: n.L3.background.speed.ground,
                                yPercent: 100,
                                ease: "none"
                            }, 0).to(".background__main", {
                                duration: n.L3.background.speed.backgroundMain,
                                yPercent: 100,
                                ease: "none"
                            }, 0).to(".clouds", {
                                duration: n.L3.background.speed.clouds,
                                yPercent: 100,
                                ease: "none"
                            }, 0).to(".wrap-moon", {
                                y: "100%",
                                duration: n.L3.background.speed.moon,
                                ease: "none"
                            }, 8).to(".stars", {
                                opacity: 1,
                                duration: 6,
                                ease: "none"
                            }, 9).to(".stars", {
                                y: "50%",
                                ease: "power3.in",
                                duration: 18
                            }, 9).to(".stars", {
                                y: "0%",
                                ease: "none",
                                duration: 0
                            }, 27).to(".stars", {
                                y: "50%",
                                ease: "none",
                                duration: 4,
                                repeat: -1
                            }, 27).call(() => this.tlAviator.play(0), null, 3).call(() => this.tlComet.play(0), null, 14).call(() => this.tlSatelite.play(0), null, 28).call(() => this.tlUfo.play(0), null, 35).call(() => this.tlTesla.play(0), null, 42).pause()
                        }
                        get isBonusGameLabelHidden() {
                            return this.isBonusGame !== n.my.No
                        }
                        get isBonusGameLabelDisabled() {
                            return this.coreService.disabled || this.disableBtnBetService.getDisabledBtn
                        }
                        onBonusInfoLabelClick() {
                            this.modal.open(X.$.HowToBonusPlay)
                        }
                        updatePlayAnim(o) {
                            switch (o) {
                                case n.Sv.ProgressGame:
                                    this.tlMain.play();
                                    break;
                                case n.Sv.BonusGame:
                                    r.p8.to(".background__bonus", {
                                        autoAlpha: 1,
                                        duration: 1
                                    }), this.tlMain.clear().to(".ground", {
                                        duration: n.L3.background.speed.ground / 2,
                                        yPercent: 100,
                                        ease: "none"
                                    }, 0).to(".clouds", {
                                        duration: n.L3.background.speed.clouds / 2,
                                        yPercent: 100,
                                        ease: "none"
                                    }, 0).play();
                                    break;
                                case n.Sv.EndGame:
                                    this.tlMain.pause(0), r.p8.set(".ground", {
                                        yPercent: 0
                                    }), r.p8.set(".clouds", {
                                        yPercent: 0
                                    }), r.p8.set(".background__bonus", {
                                        autoAlpha: 0
                                    }), this.tlAviator.pause(0), this.tlComet.pause(0), this.tlSatelite.pause(0), this.tlUfo.pause(0), this.tlTesla.pause(0);
                                    break;
                                default:
                                    this.tlMain.pause()
                            }
                        }
                        updatePlayAnimCircl() {
                            return (0, h.mG)(this, void 0, void 0, function*() {
                                if (this.isBonusGame === n.my.Yes) return yield(0, b.V)(n.L3.delay.beforeEndGameFirst), void this.tlWin.play();
                                this.winGame !== n.Kr.Win ? this.winGame === n.Kr.Init && this.tlWin.pause(0) : this.tlWin.play()
                            })
                        }
                        ngOnDestroy() {
                            this.tlMain.kill(), this.tlWin.kill(), this.tlAviator.kill(), this.tlComet.kill(), this.tlSatelite.kill(), this.tlUfo.kill(), this.tlTesla.kill()
                        }
                    }
                    return i.\u0275fac = function(o) {
                        return new(o || i)(e.Y36(A.p), e.Y36(ee.Z), e.Y36(k.i))
                    }, i.\u0275cmp = e.Xpm({
                        type: i,
                        selectors: [
                            ["app-background"]
                        ],
                        inputs: {
                            status: "status",
                            winGame: "winGame",
                            coefficients: "coefficients",
                            isBonusGame: "isBonusGame"
                        },
                        features: [e.TTD],
                        decls: 26,
                        vars: 4,
                        consts: [
                            [1, "background"],
                            [1, "background__main"],
                            [1, "background__bonus"],
                            [1, "stars"],
                            [1, "clouds"],
                            ["src", "assets/img/balloon/clouds.png", "alt", "clouds.png", "srcset", "assets/img/balloon/clouds.png, assets/img/balloon/clouds@2x.png 2x, assets/img/balloon/clouds@3x.png 3x"],
                            [1, "ground"],
                            [3, "src", "alt", "srcset"],
                            [1, "wrap-moon"],
                            ["src", "assets/img/balloon/moon.png", "alt", "moon.png", "srcset", "assets/img/balloon/moon.png, assets/img/balloon/moon@2x.png 2x, assets/img/balloon/moon@3x.png 3x", 1, "moon"],
                            [1, "wrap-aviator"],
                            [1, "aviator"],
                            ["src", "assets/img/balloon/trail.png", "alt", "trail.png", "srcset", "assets/img/balloon/trail.png, assets/img/balloon/trail@2x.png 2x, assets/img/balloon/trail@3x.png 3x", 1, "aviator__trail"],
                            [1, "wrap-comet"],
                            ["src", "assets/img/balloon/comet.png", "alt", "comet.png", "srcset", "assets/img/balloon/comet.png, assets/img/balloon/comet@2x.png 2x, assets/img/balloon/comet@3x.png 3x", 1, "comet"],
                            [1, "wrap-satelite"],
                            ["src", "assets/img/balloon/satelite.png", "alt", "satelite.png", "srcset", "assets/img/balloon/satelite.png, assets/img/balloon/satelite@2x.png 2x, assets/img/balloon/satelite@3x.png 3x", 1, "satelite"],
                            [1, "wrap-ufo"],
                            ["src", "assets/img/balloon/ufo.png", "alt", "ufo.png", "srcset", "assets/img/balloon/ufo.png, assets/img/balloon/ufo@2x.png 2x, assets/img/balloon/ufo@3x.png 3x", 1, "ufo"],
                            [1, "wrap-tesla"],
                            ["src", "assets/img/balloon/tesla.png", "alt", "tesla.png", "srcset", "assets/img/balloon/tesla.png, assets/img/balloon/tesla@2x.png 2x, assets/img/balloon/tesla@3x.png 3x", 1, "tesla"],
                            [1, "rays"],
                            ["src", "assets/icons/balloon-rays.svg"],
                            ["class", "bonus-game-label", 3, "disabled", "ngClass", "click", 4, "ngIf"],
                            [1, "bonus-game-label", 3, "disabled", "ngClass", "click"]
                        ],
                        template: function(o, s) {
                            1 & o && (e.TgZ(0, "div", 0), e._UZ(1, "div", 1), e._UZ(2, "div", 2), e.qZA(), e.TgZ(3, "div", 3), e._UZ(4, "div"), e._UZ(5, "div"), e.qZA(), e.TgZ(6, "div", 4), e._UZ(7, "img", 5), e.qZA(), e.TgZ(8, "div", 6), e._UZ(9, "img", 7), e.qZA(), e.TgZ(10, "div", 8), e._UZ(11, "img", 9), e.qZA(), e.TgZ(12, "div", 10), e.TgZ(13, "div", 11), e._UZ(14, "img", 12), e.qZA(), e.qZA(), e.TgZ(15, "div", 13), e._UZ(16, "img", 14), e.qZA(), e.TgZ(17, "div", 15), e._UZ(18, "img", 16), e.qZA(), e.TgZ(19, "div", 17), e._UZ(20, "img", 18), e.qZA(), e.TgZ(21, "div", 19), e._UZ(22, "img", 20), e.qZA(), e.TgZ(23, "div", 21), e._UZ(24, "svg-icon", 22), e.qZA(), e.YNc(25, ne, 2, 4, "button", 23)), 2 & o && (e.xp6(9), e.Q6J("src", "assets/img/balloon/location" + s.randomLocation + ".png", e.LSH)("alt", "location" + s.randomLocation + ".png")("srcset", "assets/img/balloon/location" + s.randomLocation + ".png, assets/img/balloon/location" + s.randomLocation + "@2x.png 2x, assets/img/balloon/location" + s.randomLocation + "@3x.png 3x", e.LSH), e.xp6(16), e.Q6J("ngIf", s.coreService.user.settings.isBonusGameEnabled && !s.isBonusGameLabelHidden))
                        },
                        directives: [S.bk, f.O5, f.mk],
                        styles: ['[_nghost-%COMP%]{position:absolute;top:0;left:0;width:100%;height:100%}.ground[_ngcontent-%COMP%]{position:absolute;bottom:0;left:0;width:100%;height:197px;transform:translateY(0)}@media (max-width: 767.98px){.ground[_ngcontent-%COMP%]{height:230px}}.ground[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{pointer-events:none;position:absolute;top:0;left:0;width:100%;height:auto}.clouds[_ngcontent-%COMP%]{position:absolute;top:0;left:0;width:100%;height:100%;transform:translateY(0)}.clouds[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{pointer-events:none;width:100%;height:100%;-o-object-fit:contain;object-fit:contain;transform:translateY(-17%)}.wrap-aviator[_ngcontent-%COMP%], .wrap-moon[_ngcontent-%COMP%], .wrap-satelite[_ngcontent-%COMP%], .wrap-ufo[_ngcontent-%COMP%], .wrap-tesla[_ngcontent-%COMP%], .wrap-comet[_ngcontent-%COMP%]{position:absolute;top:0;height:100%}.wrap-aviator[_ngcontent-%COMP%]   img[_ngcontent-%COMP%], .wrap-moon[_ngcontent-%COMP%]   img[_ngcontent-%COMP%], .wrap-satelite[_ngcontent-%COMP%]   img[_ngcontent-%COMP%], .wrap-ufo[_ngcontent-%COMP%]   img[_ngcontent-%COMP%], .wrap-tesla[_ngcontent-%COMP%]   img[_ngcontent-%COMP%], .wrap-comet[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{pointer-events:none}.wrap-aviator[_ngcontent-%COMP%]{left:0;width:100%;transform:translateY(-50%)}.wrap-aviator[_ngcontent-%COMP%]   .aviator[_ngcontent-%COMP%]{position:absolute;top:0;left:0%;width:100px;height:60px;background-repeat:no-repeat;transform:translate(-50%);background-image:url(/assets/img/balloon/plane.png);background-image:-webkit-image-set(url(/assets/img/balloon/plane.png) 1x,url(/assets/img/balloon/plane@2x.png) 2x,url(/assets/img/balloon/plane@3x.png) 3x);background-image:image-set("/assets/img/balloon/plane.png" 1x,"/assets/img/balloon/plane@2x.png" 2x,"/assets/img/balloon/plane@3x.png" 3x)}.wrap-aviator[_ngcontent-%COMP%]   .aviator__trail[_ngcontent-%COMP%]{position:absolute;left:0;bottom:0;transform:translate(-100%,100%)}.wrap-moon[_ngcontent-%COMP%]{right:0;transform:translateY(-100%)}.wrap-moon[_ngcontent-%COMP%]   .moon[_ngcontent-%COMP%]{position:absolute;top:0;right:0;width:532px;height:532px;border-radius:50%;transform:translate(33%,-28%)}.wrap-comet[_ngcontent-%COMP%]{left:0;width:100%;transform:translate(-272px,-100%)}.wrap-comet[_ngcontent-%COMP%]   .comet[_ngcontent-%COMP%]{position:absolute;left:0;bottom:0}.wrap-satelite[_ngcontent-%COMP%]{left:0;width:100%;transform:translateY(-100%)}.wrap-satelite[_ngcontent-%COMP%]   .satelite[_ngcontent-%COMP%]{position:absolute;left:60%;bottom:0;transform:translate(-50%)}.wrap-ufo[_ngcontent-%COMP%]{left:0;width:100%;transform:translateY(-100%)}.wrap-ufo[_ngcontent-%COMP%]   .ufo[_ngcontent-%COMP%]{position:absolute;left:40%;bottom:0;transform:translate(-50%)}.wrap-tesla[_ngcontent-%COMP%]{left:0;width:100%;transform:translate(20%,-100%)}.wrap-tesla[_ngcontent-%COMP%]   .tesla[_ngcontent-%COMP%]{position:absolute;right:0;bottom:25px;transform:rotate(320deg)}.bonus-game-label[_ngcontent-%COMP%]{position:absolute;top:37px;left:7px;z-index:1;width:42px;height:56px;background-color:transparent;background-image:url(/assets/icons/bonus-game-label.svg);background-repeat:no-repeat;padding:29px 3px 5px;border:none;color:#000;text-align:center;font-size:10px;font-style:normal;font-weight:400;line-height:normal}.bonus-game-label--disabled[_ngcontent-%COMP%]{opacity:.8}.stars[_ngcontent-%COMP%]{position:absolute;opacity:0;left:0;bottom:0;width:100%;height:200%;transform:translateY(0)}.stars[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{position:absolute;left:0;width:100%;height:50%;background-image:url(/assets/img/balloon/stars.png);background-image:-webkit-image-set(url(/assets/img/balloon/stars.png) 1x,url(/assets/img/balloon/stars@2x.png) 2x,url(/assets/img/balloon/stars@3x.png) 3x);background-image:image-set("/assets/img/balloon/stars.png" 1x,"/assets/img/balloon/stars@2x.png" 2x,"/assets/img/balloon/stars@3x.png" 3x);background-repeat:repeat;background-size:auto 100%;background-position:center center}.stars[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(1){top:0%}.stars[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(2){top:50%}.rays[_ngcontent-%COMP%]{position:absolute;opacity:0;top:50%;left:50%;width:100%;height:100%;transform:translate(-50%,-50%) rotate(0)}@media (max-width: 767.98px){.rays[_ngcontent-%COMP%]{top:calc(50% - (var(--footerHeight) + var(--headerHeight)) / 2)}}.rays[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{position:absolute;width:150vw;height:150vw;top:50%;left:50%;transform:translate(-50%,-50%)}@media (max-width: 767.98px){.rays[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:calc(100vh + 60%);height:calc(100vh + 60%)}}.background__main[_ngcontent-%COMP%], .background__bonus[_ngcontent-%COMP%]{position:absolute;top:0;left:0;width:100%;height:100%}.background__main[_ngcontent-%COMP%]{top:auto;bottom:195px;height:4377px;background-image:linear-gradient(180deg,#022059 .13%,#24afed 83.13%,#f4d690 100.13%)}@media (max-width: 767.98px){.background__main[_ngcontent-%COMP%]{bottom:230px}}.background__bonus[_ngcontent-%COMP%]{background-image:linear-gradient(180deg,#022059 .13%,#24afed 83.13%,#f4d690 100.13%)}']
                    }), i
                })(),
                ie = (() => {
                    class i {
                        constructor(o, s) {
                            this.elementRef = o, this.soundService = s, this.tlLoader = r.p8.timeline(), this.tlFire = r.p8.timeline(), this.circleAll = 214
                        }
                        ngOnInit() {
                            this.elementRef.nativeElement.style.setProperty("--delayStartViewGreenBalloon", `${n.L3.delay.startViewGreenBalloon}`), this.elementRef.nativeElement.style.setProperty("--delayViewGreenBalloon", `${n.L3.delay.viewGreenBalloon}`), this.createAnim()
                        }
                        ngOnChanges(o) {
                            var s, c;
                            (null === (s = o.status) || void 0 === s ? void 0 : s.currentValue) === n.Sv.ProgressGame ? this.tlFire.play() : this.tlFire.pause(0), (null === (c = o.status) || void 0 === c ? void 0 : c.currentValue) === n.Sv.BonusGame && (r.p8.set(".air-balloon-green__box", {
                                opacity: 1,
                                boxShadow: "none"
                            }), r.p8.set(".air-balloon-green__box-loader path", {
                                strokeDasharray: 1e3
                            }), r.p8.set(".air-balloon-green__box-path", {
                                stroke: "#89C067"
                            }), this.isBonusGame === n.my.Yes ? this.tlLoader.clear().to(".air-balloon-green__box-loader path", {
                                duration: n.L3.delay.loader / 1e3,
                                strokeDasharray: 1e3 + this.circleAll,
                                ease: "none",
                                onComplete: () => {
                                    this.soundService.playSound(a.pD.balloonBonusSuccess)
                                }
                            }, n.L3.delay.allViewGreenBalloon / 1e3).to(".air-balloon-green__box", {
                                duration: n.L3.delay.loaderFire / 1e3,
                                boxShadow: "0px 0px 16px rgba(255, 215, 0, 1)"
                            }).to(".air-balloon-green__box", {
                                duration: 0,
                                opacity: 0
                            }).play(0) : this.tlLoader.clear().to(".air-balloon-green__box-loader path", {
                                duration: n.L3.delay.loader / 1e3,
                                strokeDasharray: 1e3 + this.circleAll * r.p8.utils.random(.2, .8),
                                ease: "none",
                                onComplete: () => {
                                    this.soundService.playSound(a.pD.balloonBonusFail)
                                }
                            }, n.L3.delay.allViewGreenBalloon / 1e3).to(".air-balloon-green__box-path", {
                                duration: n.L3.delay.loaderFire / 1e3,
                                stroke: "#FF6042"
                            }).to(".air-balloon-green__box", {
                                duration: 0,
                                opacity: 0
                            }).play(0))
                        }
                        get balloonRedClasses() {
                            return {
                                "air-balloon-red_end": this.status === n.Sv.BonusGame || this.status === n.Sv.BeforeEndGame,
                                "air-balloon-red_progress-game": this.status !== n.Sv.Init && this.status !== n.Sv.StartGame && this.status !== n.Sv.EndGame
                            }
                        }
                        get balloonGreenClasses() {
                            return {
                                "air-balloon-green_view": (this.status === n.Sv.BonusGame || this.status === n.Sv.BeforeEndGame) && this.isBonusGame !== n.my.No,
                                "air-balloon-green_end": this.winGame !== n.Kr.Init && this.isBonusGame !== n.my.No
                            }
                        }
                        createAnim() {
                            this.tlFire.to(".air-balloon-red__fire", {
                                backgroundPosition: "-32px 0px",
                                ease: "steps(2)",
                                duration: .3,
                                repeat: -1
                            }, 0).to(".air-balloon-red__fire", {
                                scale: 1,
                                duration: .5
                            }, 0).pause()
                        }
                        ngOnDestroy() {
                            this.tlLoader.kill(), this.tlFire.kill()
                        }
                    }
                    return i.\u0275fac = function(o) {
                        return new(o || i)(e.Y36(e.SBq), e.Y36(a.yu))
                    }, i.\u0275cmp = e.Xpm({
                        type: i,
                        selectors: [
                            ["app-air-balloon"]
                        ],
                        inputs: {
                            isBonusGame: "isBonusGame",
                            winGame: "winGame",
                            status: "status"
                        },
                        features: [e.TTD],
                        decls: 13,
                        vars: 2,
                        consts: [
                            [1, "air-balloon-red", 3, "ngClass"],
                            [1, "air-balloon-red__fire"],
                            ["src", "assets/img/balloon/airballoon-red.png", "alt", "", "srcset", "\n      assets/img/balloon/airballoon-red.png,\n      assets/img/balloon/airballoon-red@2x.png 2x,\n      assets/img/balloon/airballoon-red@3x.png 3x\n    ", 1, "air-balloon-red__balloon"],
                            [1, "air-balloon-green", 3, "ngClass"],
                            [1, "air-balloon-green__box"],
                            ["src", "assets/img/svg/balloon-loader.svg", 1, "air-balloon-green__box-bg"],
                            ["width", "76", "height", "76", "viewBox", "0 0 76 76", "fill", "none", "xmlns", "http://www.w3.org/2000/svg", 1, "air-balloon-green__box-loader"],
                            ["d", "M37.9999 72C56.7776 72 71.9999 56.7777 71.9999 38C71.9999 19.2223 56.7776 4 37.9999 4C19.2223 4 4 19.2223 4 38C4 56.7777 19.2223 72 37.9999 72Z", "stroke", "#89C067", "stroke-width", "4", 1, "air-balloon-green__box-path"],
                            [1, "air-balloon-green__box-text"],
                            ["src", "assets/icons/balloon-star.svg"]
                        ],
                        template: function(o, s) {
                            1 & o && (e.TgZ(0, "div", 0), e._UZ(1, "div", 1), e._UZ(2, "img", 2), e.qZA(), e.TgZ(3, "div", 3), e.TgZ(4, "div", 4), e._UZ(5, "svg-icon", 5), e.O4$(), e.TgZ(6, "svg", 6), e._UZ(7, "path", 7), e.qZA(), e.kcU(), e.TgZ(8, "div", 8), e._UZ(9, "svg-icon", 9), e.TgZ(10, "span"), e._uU(11, "BONUS"), e.qZA(), e._uU(12, " GAME "), e.qZA(), e.qZA(), e.qZA()), 2 & o && (e.Q6J("ngClass", s.balloonRedClasses), e.xp6(3), e.Q6J("ngClass", s.balloonGreenClasses))
                        },
                        directives: [f.mk, S.bk],
                        styles: ['.air-balloon-red[_ngcontent-%COMP%], .air-balloon-green[_ngcontent-%COMP%]{width:244px;height:314px;background-size:contain;background-repeat:no-repeat;background-position:center}@media (max-width: 767.98px){.air-balloon-red[_ngcontent-%COMP%], .air-balloon-green[_ngcontent-%COMP%]{width:200px;height:258px}}.air-balloon-red[_ngcontent-%COMP%]{position:absolute;top:50%;left:50%;display:flex;transform:translate(-50%,-50%)}@media (max-width: 767.98px){.air-balloon-red[_ngcontent-%COMP%]{top:auto;bottom:calc(var(--footerHeight) + var(--headerHeight) + 11px);transform:translate(-50%)}}@media (max-width: 767.98px){.air-balloon-red_progress-game[_ngcontent-%COMP%]{bottom:calc(50% + (var(--footerHeight) + var(--headerHeight)) / 2);transform:translate(-50%,50%);transition:bottom .5s ease-in-out,transform .5s ease-in-out}}.air-balloon-red_end[_ngcontent-%COMP%]{top:0;transform:translate(-50%,-100%);transition:transform .5s ease-in-out,top .5s ease-in-out}@media (max-width: 767.98px){.air-balloon-red_end[_ngcontent-%COMP%]{top:auto;bottom:100%;transform:translate(-50%);transition:bottom .5s ease-in-out,transform .5s ease-in-out}}.air-balloon-red__balloon[_ngcontent-%COMP%]{position:absolute;width:100%;height:100%;-o-object-fit:contain;object-fit:contain}.air-balloon-red__fire[_ngcontent-%COMP%]{position:absolute;top:80%;left:50%;width:16px;height:30px;background-image:url(/assets/img/balloon/fire.png);background-image:-webkit-image-set(url(/assets/img/balloon/fire.png) 1x,url(/assets/img/balloon/fire@2x.png) 2x,url(/assets/img/balloon/fire@3x.png) 3x);background-image:image-set("/assets/img/balloon/fire.png" 1x,"/assets/img/balloon/fire@2x.png" 2x,"/assets/img/balloon/fire@3x.png" 3x);background-repeat:no-repeat;transform:translate(-50%,-50%) scale(0);transform-origin:50% 100%}.air-balloon-green[_ngcontent-%COMP%]{position:absolute;bottom:0;left:50%;display:flex;transform:translate(-50%,100%);background-image:url(air-balloon-green.cbefec61d533a89b.svg)}.air-balloon-green__box[_ngcontent-%COMP%]{position:absolute;top:37px;left:50%;border-radius:50%;transform:translate(-50%)}@media (max-width: 767.98px){.air-balloon-green__box[_ngcontent-%COMP%]{top:14px}}.air-balloon-green__box-bg[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:170px;height:170px}.air-balloon-green__box-loader[_ngcontent-%COMP%]{position:absolute;top:5px;left:5px;width:160px;height:160px;transform:scaleY(-1)}.air-balloon-green__box-loader[_ngcontent-%COMP%]   path[_ngcontent-%COMP%]{stroke-dasharray:1000;stroke-dashoffset:1000}.air-balloon-green__box-text[_ngcontent-%COMP%]{position:absolute;top:50%;left:50%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;font-size:12px;color:#151719;transform:translate(-50%,-50%)}.air-balloon-green__box-text[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:18px;font-style:normal;font-weight:700;line-height:normal;border-bottom:1px solid #151719;margin-top:2px}.air-balloon-green_view[_ngcontent-%COMP%]{bottom:50%;left:50%;transform:translate(-50%,50%);transition:calc(var(--delayStartViewGreenBalloon) / 1000 * 1s) bottom calc(var(--delayViewGreenBalloon) / 1000 * 1s) ease-in-out,calc(var(--delayStartViewGreenBalloon) / 1000 * 1s) transform calc(var(--delayViewGreenBalloon) / 1000 * 1s) ease-in-out}@media (max-width: 767.98px){.air-balloon-green_view[_ngcontent-%COMP%]{top:auto;bottom:calc(50% + (var(--footerHeight) + var(--headerHeight)) / 2);transform:translate(-50%,50%)}}.air-balloon-green_end[_ngcontent-%COMP%]{top:0;transform:translate(-50%,-100%);transition:transform .5s ease-in-out,top .5s ease-in-out}@media (max-width: 767.98px){.air-balloon-green_end[_ngcontent-%COMP%]{top:auto;bottom:100%;transform:translate(-50%);transition:bottom .5s ease-in-out,transform .5s ease-in-out}}']
                    }), i
                })();
            const se = ["coefficientFlyRef"],
                ae = ["coefficientRef"],
                re = ["coefficientFirstRef"];
            let le = (() => {
                class i {
                    constructor(o, s) {
                        this.elementRef = o, this.soundService = s, this.endGameAfter = new e.vpe, this.bonusCoefficient = {
                            value: 0
                        }, this.tlCoefficientFly = r.p8.timeline(), this.coefficientScale = r.p8.timeline()
                    }
                    ngOnChanges(o) {
                        this.checkEditIndexBonusCoefficient(o), this.checkWinGame(o), this.checkStatus(o)
                    }
                    ngOnInit() {
                        this.createAnim(), this.coefficientRef.nativeElement.style.setProperty("--balloonDelayMoveCoefficient", `${n.L3.delay.moveCoefficient}`)
                    }
                    get coefficientClasses() {
                        return {
                            "coefficient_progress-game": this.status !== n.Sv.Init && this.status !== n.Sv.StartGame && this.status !== n.Sv.EndGame
                        }
                    }
                    get coefficientBonusClasses() {
                        return {
                            coefficient__bonus_view: 0 !== this.coefficients.bonusCoefficients,
                            coefficient__bonus_hide: this.status === n.Sv.BeforeEndGame && this.bonusCoefficient.value <= 0
                        }
                    }
                    checkEditIndexBonusCoefficient(o) {
                        if (o.indexBonusCoefficient) {
                            if (0 === this.updateBonusCoefficient) return void(this.bonusCoefficient.value = 0);
                            this.tlCoefficientFly.play(0)
                        }
                    }
                    createAnim() {
                        this.tlCoefficientFly.fromTo(this.coefficientFlyRef.nativeElement, {
                            duration: 0,
                            y: 0,
                            x: "-50%"
                        }, {
                            duration: n.L3.delay.animNumb / 1e3,
                            display: "flex",
                            color: "#ffe245",
                            y: this.elementRef.nativeElement.clientWidth <= 757 ? this.elementRef.nativeElement.clientHeight / 2 - 169 : this.elementRef.nativeElement.clientHeight / 2 - 63,
                            x: "-50%"
                        }, 0).fromTo(this.coefficientFlyRef.nativeElement, {
                            duration: 0,
                            scale: 1
                        }, {
                            duration: n.L3.delay.animNumb / 1e3 * .5,
                            scale: 2.4
                        }, 0).to(this.coefficientFlyRef.nativeElement, {
                            duration: n.L3.delay.animNumb / 1e3 * .5,
                            scale: 1.75
                        }, n.L3.delay.animNumb / 1e3 * .5).to(this.coefficientFlyRef.nativeElement, {
                            duration: n.L3.delay.animNumb / 1e3 * .2,
                            opacity: 0,
                            onComplete: () => {
                                r.p8.to(this.bonusCoefficient, {
                                    value: _.t.sum(this.bonusCoefficient.value, this.updateBonusCoefficient).toNumber(),
                                    duration: n.L3.delay.animNumb / 1e3,
                                    ease: "none",
                                    onStart: () => {
                                        this.soundService.playSound(a.pD.balloonSumCounter)
                                    },
                                    onComplete: () => {
                                        this.soundService.stopSound(a.pD.balloonSumCounter)
                                    }
                                })
                            }
                        }, n.L3.delay.animNumb / 1e3 * .8).pause(), this.coefficientScale.to(this.coefficientFirstRef.nativeElement, {
                            duration: n.L3.delay.beforeEndGameSecond / 1e3,
                            y: 150,
                            ease: "Power1.easeOut"
                        }, 0).to(this.coefficientFirstRef.nativeElement, {
                            duration: n.L3.delay.beforeEndGameSecond / 1e3 * .6,
                            opacity: 1,
                            scale: 2,
                            ease: "Power3.easeOut"
                        }, 0).to(this.coefficientFirstRef.nativeElement, {
                            duration: n.L3.delay.beforeEndGameSecond / 1e3 * .4,
                            opacity: 0,
                            scale: .7,
                            ease: "Power3.easeOut",
                            onComplete: () => {
                                r.p8.set(this.coefficientFirstRef.nativeElement, {
                                    opacity: 1,
                                    scale: 1,
                                    y: 0
                                }), this.endGameAfter.emit()
                            }
                        }, n.L3.delay.beforeEndGameSecond / 1e3 * .6).pause()
                    }
                    checkStatus(o) {
                        var s, c;
                        switch (null === (s = o.status) || void 0 === s ? void 0 : s.currentValue) {
                            case n.Sv.EndGame:
                                r.p8.set(this.coefficientFirstRef.nativeElement, {
                                    color: "#fff"
                                }), this.bonusCoefficient.value = 0;
                                break;
                            case n.Sv.BonusGame:
                                r.p8.set(this.coefficientRef.nativeElement, {
                                    opacity: 0
                                }), 0 === (null === (c = this.coefficients) || void 0 === c ? void 0 : c.currentCoefficient) && r.p8.set(this.coefficientFirstRef.nativeElement, {
                                    color: "#000"
                                }), r.p8.set(this.coefficientRef.nativeElement, {
                                    opacity: 1,
                                    delay: n.L3.delay.startBonusGameFirst / 1e3
                                })
                        }
                    }
                    checkWinGame(o) {
                        var s, c;
                        (null === (s = o.winGame) || void 0 === s ? void 0 : s.currentValue) === n.Kr.Win ? (r.p8.set(this.coefficientFirstRef.nativeElement, {
                            color: "#66b405"
                        }), this.bonusCoefficient.value > 0 ? this.startAnimCoef(n.L3.delay.beforeEndGameFirst, "first") : this.startAnimCoef(n.L3.delay.stepCycleNumbers, null)) : (null === (c = o.winGame) || void 0 === c ? void 0 : c.currentValue) === n.Kr.Lose && (this.bonusCoefficient.value > 0 ? this.startAnimCoef(n.L3.delay.beforeEndGameFirst, "second") : (r.p8.set(this.coefficientFirstRef.nativeElement, {
                            color: "#000"
                        }), this.startAnimCoef(n.L3.delay.stepCycleNumbers, null, !1)))
                    }
                    startAnimCoef(o, s, c = !0) {
                        c ? this.coefficientScale.play(o / 1e3 * -1) : setTimeout(() => {
                            this.endGameAfter.emit()
                        }, n.L3.delay.beforeEndGameSecond), "second" === s && (this.coefficients.currentCoefficient = 0, r.p8.set(this.coefficientFirstRef.nativeElement, {
                            color: "#66b405"
                        })), r.p8.to(this.coefficients, {
                            currentCoefficient: _.t.sum(this.bonusCoefficient.value, this.coefficients.currentCoefficient).toNumber(),
                            duration: o / 1e3,
                            ease: "none"
                        }), r.p8.to(this.bonusCoefficient, {
                            value: 0,
                            duration: o / 1e3,
                            ease: "none"
                        })
                    }
                    ngOnDestroy() {
                        this.tlCoefficientFly.kill(), this.coefficientScale.kill()
                    }
                }
                return i.\u0275fac = function(o) {
                    return new(o || i)(e.Y36(e.SBq), e.Y36(a.yu))
                }, i.\u0275cmp = e.Xpm({
                    type: i,
                    selectors: [
                        ["app-coefficient"]
                    ],
                    viewQuery: function(o, s) {
                        if (1 & o && (e.Gf(se, 7), e.Gf(ae, 7), e.Gf(re, 7)), 2 & o) {
                            let c;
                            e.iGM(c = e.CRH()) && (s.coefficientFlyRef = c.first), e.iGM(c = e.CRH()) && (s.coefficientRef = c.first), e.iGM(c = e.CRH()) && (s.coefficientFirstRef = c.first)
                        }
                    },
                    inputs: {
                        coefficients: "coefficients",
                        winGame: "winGame",
                        updateBonusCoefficient: "updateBonusCoefficient",
                        indexBonusCoefficient: "indexBonusCoefficient",
                        isBonusGame: "isBonusGame",
                        status: "status"
                    },
                    outputs: {
                        endGameAfter: "endGameAfter"
                    },
                    features: [e.TTD],
                    decls: 10,
                    vars: 5,
                    consts: [
                        [1, "coefficient", 3, "ngClass"],
                        ["coefficientRef", ""],
                        [1, "coefficient__main"],
                        ["coefficientFirstRef", ""],
                        [1, "coefficient__bonus", 3, "ngClass"],
                        [1, "coefficient-fly"],
                        ["coefficientFlyRef", ""]
                    ],
                    template: function(o, s) {
                        1 & o && (e.TgZ(0, "div", 0, 1), e.TgZ(2, "span", 2, 3), e._uU(4), e.qZA(), e.TgZ(5, "span", 4), e._uU(6), e.qZA(), e.qZA(), e.TgZ(7, "div", 5, 6), e._uU(9), e.qZA()), 2 & o && (e.Q6J("ngClass", s.coefficientClasses), e.xp6(4), e.hij(" ", null == s.coefficients || null == s.coefficients.currentCoefficient ? null : s.coefficients.currentCoefficient.toFixed(2), " "), e.xp6(1), e.Q6J("ngClass", s.coefficientBonusClasses), e.xp6(1), e.hij(" ", s.bonusCoefficient.value.toFixed(2), " "), e.xp6(3), e.hij(" ", null == s.updateBonusCoefficient ? null : s.updateBonusCoefficient.toFixed(1), "\n"))
                    },
                    directives: [f.mk],
                    styles: ['[_nghost-%COMP%]{position:absolute;top:0;left:0;width:100%;height:100%}@media (max-width: 767.98px){[_nghost-%COMP%]{--moveCoefficientBonusLastTop: calc(50% - (var(--footerHeight) + var(--headerHeight)) / 2)}}.coefficient[_ngcontent-%COMP%]{position:absolute;top:42%;left:50%;display:flex;flex-direction:column;align-items:center;text-align:center;color:#fff;font-size:42px;font-style:normal;font-weight:700;line-height:normal;text-shadow:0 1px 0 rgba(0,0,0,.5);transform:translate(-50%,-50%)}@media (max-width: 767.98px){.coefficient[_ngcontent-%COMP%]{top:auto;bottom:calc(var(--footerHeight) + var(--headerHeight) + 140px);transform:translate(-50%)}}@media (max-width: 767.98px){.coefficient_progress-game[_ngcontent-%COMP%]{bottom:calc(50% + (var(--footerHeight) + var(--headerHeight)) / 2 + 30px);transform:translate(-50%,50%);transition:bottom .5s ease-in-out,transform .5s ease-in-out}}.coefficient__main[_ngcontent-%COMP%]{display:flex;align-items:baseline;font-weight:700;line-height:1.1666666667}.coefficient__main[_ngcontent-%COMP%]:after{content:"X";font-size:32px}.coefficient__bonus[_ngcontent-%COMP%]{display:flex;align-items:baseline;font-weight:700;overflow:hidden;height:0;color:#ffe245;font-size:28px;line-height:1.1785714286}.coefficient__bonus[_ngcontent-%COMP%]:before{content:"+";font-size:21px}.coefficient__bonus[_ngcontent-%COMP%]:after{content:"X";font-size:21px}.coefficient__bonus_view[_ngcontent-%COMP%]{height:33px;transition:calc(var(--balloonDelayMoveCoefficient) / 1000 * 1s) height .15s ease-in}.coefficient__bonus_hide[_ngcontent-%COMP%]{opacity:0}.coefficient-fly[_ngcontent-%COMP%]{position:absolute;z-index:1;display:none;top:41px;left:50%;color:#fff;text-shadow:0 1px 0 rgba(0,0,0,.5);font-size:16px;font-weight:700;transform:translate(-50%)}@media (max-width: 767.98px){.coefficient-fly[_ngcontent-%COMP%]{top:53px}}.coefficient-fly[_ngcontent-%COMP%]:after{content:"X"}']
                }), i
            })();
            const ce = ["bonusGameSpinerRef"],
                ue = ["bonusGameSpinerWrapLineRef"];

            function me(i, t) {
                if (1 & i && (e.TgZ(0, "div", 16), e._uU(1), e.qZA()), 2 & i) {
                    const o = t.$implicit;
                    e.xp6(1), e.hij(" ", o.toFixed(1), " ")
                }
            }
            let v = class {
                constructor(t, o) {
                    this.coreService = t, this.soundService = o, this.updateBonusCoef = new e.vpe, this.randomBonuses = [], this.tlBonusGameSpiner = r.p8.timeline(), this.bonusGameSpinerRightCircl = r.p8.timeline()
                }
                ngOnChanges(t) {
                    var o, s;
                    (null === (s = null === (o = t.bonusCoefficients) || void 0 === o ? void 0 : o.currentValue) || void 0 === s ? void 0 : s.length) && this.startSpiner(t.bonusCoefficients.currentValue)
                }
                ngOnInit() {
                    this.generateRandomBonuses(), this.applyStyle(), this.createAnim()
                }
                get gameConfig() {
                    return this.coreService.gameConfig
                }
                get startPositionLeft() {
                    return this.bonusGameSpinerWrapLineRef.nativeElement.clientWidth / 2 - n.L3.bonusGame.halfItemTotalWidth - n.L3.bonusGame.itemTotalWidth * this.gameConfig.bonusCoefficients.length
                }
                get startPositionRight() {
                    return this.startPositionLeft + n.L3.bonusGame.itemTotalWidth - n.L3.bonusGame.itemTotalWidth * this.gameConfig.bonusCoefficients.length * (this.randomBonuses.length / this.gameConfig.bonusCoefficients.length - 2)
                }
                applyStyle() {
                    r.p8.set(this.bonusGameSpinerRef.nativeElement, {
                        "--itemWidth": n.L3.bonusGame.itemWidth
                    }), r.p8.set(this.bonusGameSpinerRef.nativeElement, {
                        "--itemIndent": n.L3.bonusGame.itemIndent
                    }), r.p8.set(this.bonusGameSpinerRef.nativeElement, {
                        "--widthRight": n.L3.bonusGame.widthRight
                    }), r.p8.set(this.bonusGameSpinerRef.nativeElement, {
                        "--widthLeft": n.L3.bonusGame.widthLeft
                    }), r.p8.set(this.bonusGameSpinerRef.nativeElement, {
                        "--startPositionLeft": this.startPositionLeft
                    })
                }
                generateRandomBonuses() {
                    if (!this.randomBonuses.length)
                        for (let t = 0; t < 11; t++) this.randomBonuses.push(...this.gameConfig.bonusCoefficients)
                }
                createAnim() {
                    this.tlBonusGameSpiner.to(".bonus-game__spiner", {
                        duration: n.L3.delay.startBonusGameSecond / 1e3,
                        y: "0%",
                        ease: "power1.inOut"
                    }, n.L3.delay.startBonusGameFirst / 1e3).to(".bonus-game__spiner", {
                        duration: n.L3.delay.startBonusGameSecond / 1e3 / 2,
                        y: "-100%",
                        ease: "power1.inOut"
                    }, (n.L3.delay.startBonusGame + 3 * n.L3.delay.stepBonusGame) / 1e3).pause(), this.bonusGameSpinerRightCircl.to(".bonus-game__spiner-right-circl span", {
                        duration: 0,
                        opacity: 0
                    }, 0).to(".bonus-game__spiner-right-circl span", {
                        duration: .15,
                        opacity: 1,
                        scale: 1.5
                    }, n.L3.delay.startBonusGame / 1e3).to(".bonus-game__spiner-right-circl span", {
                        direction: .15,
                        scale: 1
                    }, n.L3.delay.startBonusGame / 1e3 + .15).pause()
                }
                startSpiner(t) {
                    this.reverseIndexBonus = 0, this.oldSelectItem = 1, this.bonusGameSpinerRightCircl.play(0), this.tlBonusGameSpiner.play(0), (0, G.H)(n.L3.delay.startBonusGame, n.L3.delay.stepBonusGame).pipe((0, x.q)(t.length), (0, m.t)(this)).subscribe(o => {
                        this.soundService.playSound(a.pD.balloonScrollRoulette), this.reverseIndexBonus = t.length - o;
                        let c, d, s = this.gameConfig.bonusCoefficients.findIndex(g => g === t[o]) + 1;
                        this.reverseIndexBonus % 2 != 0 ? (c = this.startPositionLeft - (this.oldSelectItem - 1) * n.L3.bonusGame.itemTotalWidth, d = this.startPositionRight - s * n.L3.bonusGame.itemTotalWidth + n.L3.bonusGame.itemTotalWidth * this.gameConfig.bonusCoefficients.length) : (c = this.startPositionRight - this.oldSelectItem * n.L3.bonusGame.itemTotalWidth + n.L3.bonusGame.itemTotalWidth * this.gameConfig.bonusCoefficients.length, d = this.startPositionLeft - (s - 1) * n.L3.bonusGame.itemTotalWidth), r.p8.set(".bonus-game__spiner-line", {
                            x: c
                        }), r.p8.to(".bonus-game__spiner-line", {
                            duration: n.L3.delay.spinBonusGame / 1e3,
                            x: d,
                            ease: "cubic-bezier(0, 1.1, 1, 0.98)",
                            onComplete: () => {
                                let g;
                                g = this.reverseIndexBonus % 2 != 0 ? this.bonusGameSpinerWrapLineRef.nativeElement.querySelectorAll(".bonus-game__spiner-item")[this.randomBonuses.length - 2 * this.gameConfig.bonusCoefficients.length + s - 1] : this.bonusGameSpinerWrapLineRef.nativeElement.querySelectorAll(".bonus-game__spiner-item")[this.gameConfig.bonusCoefficients.length + s - 1], r.p8.set(g, {
                                    color: "#ffe245"
                                }), r.p8.set(g, {
                                    color: "#fff",
                                    delay: n.L3.delay.selectedBonus / 1e3
                                }), this.soundService.stopSound(a.pD.balloonScrollRoulette), this.soundService.playSound(a.pD.balloonEndRoulette), this.soundService.playSound(a.pD.balloonBonusWin), setTimeout(() => {
                                    this.soundService.playSound(a.pD.balloonBonusWinStop)
                                }, n.L3.delay.moveCoefficient), this.updateBonusCoef.emit({
                                    coef: t[o],
                                    index: o
                                })
                            }
                        }).play(), this.oldSelectItem = s
                    })
                }
                ngOnDestroy() {
                    this.tlBonusGameSpiner.kill(), this.bonusGameSpinerRightCircl.kill()
                }
            };
            v.\u0275fac = function(t) {
                return new(t || v)(e.Y36(A.p), e.Y36(a.yu))
            }, v.\u0275cmp = e.Xpm({
                type: v,
                selectors: [
                    ["app-bonus-game"]
                ],
                viewQuery: function(t, o) {
                    if (1 & t && (e.Gf(ce, 7), e.Gf(ue, 7)), 2 & t) {
                        let s;
                        e.iGM(s = e.CRH()) && (o.bonusGameSpinerRef = s.first), e.iGM(s = e.CRH()) && (o.bonusGameSpinerWrapLineRef = s.first)
                    }
                },
                inputs: {
                    coefficients: "coefficients",
                    isBonusGame: "isBonusGame",
                    bonusCoefficients: "bonusCoefficients",
                    status: "status"
                },
                outputs: {
                    updateBonusCoef: "updateBonusCoef"
                },
                features: [e.TTD],
                decls: 19,
                vars: 2,
                consts: [
                    [1, "bonus-game"],
                    [1, "bonus-game__spiner"],
                    ["bonusGameSpinerRef", ""],
                    [1, "bonus-game__spiner-bg"],
                    [1, "bonus-game__spiner-wrap"],
                    [1, "bonus-game__spiner-wrap-line"],
                    ["bonusGameSpinerWrapLineRef", ""],
                    [1, "bonus-game__spiner-line"],
                    ["class", "bonus-game__spiner-item", 4, "ngFor", "ngForOf"],
                    [1, "bonus-game__spiner-left"],
                    [1, "bonus-game__spiner-left-bg"],
                    ["src", "assets/icons/icon-balloon-star.svg", 1, "bonus-game__spiner-star"],
                    [1, "bonus-game__spiner-text"],
                    [1, "bonus-game__spiner-right"],
                    [1, "bonus-game__spiner-right-bg"],
                    [1, "bonus-game__spiner-right-circl"],
                    [1, "bonus-game__spiner-item"]
                ],
                template: function(t, o) {
                    1 & t && (e.TgZ(0, "div", 0), e.TgZ(1, "div", 1, 2), e.TgZ(3, "div", 3), e.TgZ(4, "div", 4), e.TgZ(5, "div", 5, 6), e.TgZ(7, "div", 7), e.YNc(8, me, 2, 1, "div", 8), e.qZA(), e.qZA(), e.TgZ(9, "div", 9), e._UZ(10, "div", 10), e._UZ(11, "svg-icon", 11), e.TgZ(12, "span", 12), e._uU(13, "BONUS GAME"), e.qZA(), e.qZA(), e.TgZ(14, "div", 13), e._UZ(15, "div", 14), e.TgZ(16, "div", 15), e.TgZ(17, "span"), e._uU(18), e.qZA(), e.qZA(), e.qZA(), e.qZA(), e.qZA(), e.qZA(), e.qZA()), 2 & t && (e.xp6(8), e.Q6J("ngForOf", o.randomBonuses), e.xp6(10), e.hij(" ", o.reverseIndexBonus, " "))
                },
                directives: [f.sg, S.bk],
                styles: ['.bonus-game[_ngcontent-%COMP%]{position:absolute;top:0;left:0;width:100%;height:100%}.bonus-game__spiner[_ngcontent-%COMP%]{position:absolute;top:0px;left:0;display:flex;justify-content:center;width:100%;padding-top:40px;transform:translateY(-100%)}.bonus-game__spiner-bg[_ngcontent-%COMP%]{flex-grow:1;display:flex;justify-content:center;background-color:#15171966}.bonus-game__spiner-wrap[_ngcontent-%COMP%]{position:relative;width:100%;max-width:600px;height:40px;margin:5px}.bonus-game__spiner-wrap[_ngcontent-%COMP%]:before, .bonus-game__spiner-wrap[_ngcontent-%COMP%]:after{content:"";position:absolute;z-index:1;left:50%;width:40px;height:14px;background-repeat:no-repeat;background-size:contain;transform:translate(-50%)}.bonus-game__spiner-wrap[_ngcontent-%COMP%]:before{top:-3px;background-image:url(/assets/icons/icon-balloon-arrow-top.svg)}.bonus-game__spiner-wrap[_ngcontent-%COMP%]:after{bottom:-3px;background-image:url(/assets/icons/icon-balloon-arrow-bot.svg)}.bonus-game__spiner-left[_ngcontent-%COMP%]{position:absolute;left:0;top:0;width:calc(var(--widthLeft) * 1px);height:40px}.bonus-game__spiner-left-bg[_ngcontent-%COMP%]{position:absolute;top:0;left:0;width:100%;height:100%;background-image:url(/assets/icons/icon-balloon-figure-left.svg);background-repeat:no-repeat;background-size:contain}.bonus-game__spiner-star[_ngcontent-%COMP%]{position:absolute;top:50%;right:10px;transform:translateY(-50%)}.bonus-game__spiner-text[_ngcontent-%COMP%]{position:absolute;top:53%;left:8px;width:38px;text-align:center;font-size:11px;line-height:1.1818181818;color:#000;transform:translateY(-50%)}.bonus-game__spiner-right[_ngcontent-%COMP%]{position:absolute;right:-1px;top:0;width:calc(var(--widthRight) * 1px);height:40px}.bonus-game__spiner-right-circl[_ngcontent-%COMP%]{position:absolute;top:50%;right:4px;display:flex;justify-content:center;align-items:center;width:32px;height:32px;font-size:18px;font-weight:700;line-height:1;color:#000;border-radius:50%;border:2px solid #000;transform:translateY(-50%)}.bonus-game__spiner-right-circl[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{visibility:visible;opacity:1}.bonus-game__spiner-right-bg[_ngcontent-%COMP%]{position:absolute;top:0;left:0;width:100%;height:100%;background-image:url(/assets/icons/icon-balloon-figure-right.svg);background-repeat:no-repeat;background-size:contain}.bonus-game__spiner-wrap-line[_ngcontent-%COMP%]{overflow:hidden;position:absolute;top:50%;left:0;width:100%;height:30px;transform:translateY(-50%)}.bonus-game__spiner-line[_ngcontent-%COMP%]{position:absolute;top:0;left:0;display:flex;width:auto;height:100%;transform:translate(calc(var(--startPositionLeft) * 1px))}.bonus-game__spiner-item[_ngcontent-%COMP%]{flex-shrink:0;display:flex;justify-content:center;align-items:center;width:calc(var(--itemWidth) * 1px);height:100%;color:#fff;font-size:16px;font-weight:700;margin-left:calc(var(--itemIndent) * 1px);margin-right:calc(var(--itemIndent) * 1px);border-radius:6px;background-color:#3e8a27}.bonus-game__spiner-item[_ngcontent-%COMP%]:after{content:"x"}']
            }), v = (0, h.gn)([(0, m.c)()], v);
            let C = class {
                constructor(t, o, s, c, d, g, ge, be, ve, Ce) {
                    this.betControlsService = t, this.coreService = o, this.connectorService = s, this.translocoService = c, this.soundService = d, this.disableBtnBetService = g, this.toast = ge, this.maxWinService = be, this.ifcSeenderService = ve, this.ifcApiService = Ce, this.isBonusGame = n.my.No, this.step = 0, this.isAutoplay = !1, this.gameActionWaitSendStatus = !1, this.lastMouseDownTimestamp = 0, this.lastMouseUpTimestamp = 0
                }
                ngOnInit() {
                    this.maxWinService.profit = 0, this.soundService.addOptionsMusicIsLoop(a.J9.balloonBgMusic, !0), this.soundService.addOptionsSoundIsLoop(a.pD.balloonAutoCashoutCountdown, !0), this.soundService.addOptionsMusicIsLoop(a.J9.balloonBgMusicBonusGame, !0), this.soundService.addOptionsSoundIsLoop(a.pD.balloonScrollRoulette, !0), this.soundService.addOptionsSoundIsLoop(a.pD.balloonSumCounter, !0), this.soundService.addOptionsSoundIsLoop(a.pD.balloonFly, !0), this.soundService.addOptionsSoundIsLoop(a.pD.balloonAmb, !0), this.soundService.playMusic(a.J9.balloonBgMusic), this.dataHeat = {
                        text: this.translocoService.translate("shared.Press to bet!"),
                        status: this.status,
                        startAnim: null
                    }, this.betControlsService.state.balloonHeat.setData(this.dataHeat), this.coefficients = {
                        bonusCoefficients: 0,
                        currentCoefficient: 0
                    }, this.updateBonusCoefficient = 0, this.winGame = n.Kr.Init, this.status = n.Sv.Init, this.subscribeBetControls(), this.subscribeAutoplayBetResponse(), this.subscribeGameActionResponse(), this.subscribeCashoutResponse(), this.coreService.freeBets.onResetFreeBet$.pipe((0, m.t)(this)).subscribe(() => {
                        this.betControlsService.enableAll(), this.status = n.Sv.EndGame, this.coreService.invokeEndRound()
                    })
                }
                get config() {
                    return this.coreService.config
                }
                get gameConfig() {
                    return this.coreService.gameConfig
                }
                set betControlTake(t) {
                    this.betControlsService.state.balloonTake.setData(new _.t(t).toFixed(this.config.betPrecision, _.t.ROUND_DOWN))
                }
                get status() {
                    return this._status
                }
                set status(t) {
                    if (this._status !== t && (this._status !== n.Sv.Init && this._status !== n.Sv.EndGame && this._status !== n.Sv.BeforeEndGame || t !== n.Sv.PauseGame)) switch (this._status = t, this.dataHeat.status = t, t) {
                        case n.Sv.Init:
                            this.statusInit();
                            break;
                        case n.Sv.StartGame:
                            this.statusStartGame();
                            break;
                        case n.Sv.ProgressGame:
                            this.statusProgressGame();
                            break;
                        case n.Sv.PauseGame:
                            this.statusPauseGame();
                            break;
                        case n.Sv.BonusGame:
                            this.statusBonusGame();
                            break;
                        case n.Sv.BeforeEndGame:
                            this.statusBeforeEndGame();
                            break;
                        case n.Sv.EndGame:
                            this.statusEndGame()
                    }
                }
                statusInit() {
                    this.isFirstProgressGame = !0, this.betControlTake = 0, this.betControlsService.show([u.w.Autoplay, u.w.BalloonHeat, u.w.BalloonTake]), this.betControlsService.disable([u.w.BalloonTake])
                }
                statusStartGame() {
                    this.soundService.playSound(a.pD.balloonAmb), this.betControlsService.disable(this.isAutoplay ? [u.w.BetInput, u.w.BalloonTake, u.w.BalloonHeat] : [u.w.BetInput, u.w.Autoplay, u.w.BalloonTake])
                }
                statusProgressGame() {
                    var t;
                    this.startTimeoutViewKeep(!1), this.soundService.stopSound(a.pD.balloonAutoCashoutCountdown), null === (t = this.timerAutoCashout$) || void 0 === t || t.unsubscribe(), this.isFirstProgressGame = !1, this.soundService.playSound(a.pD.balloonFly), this.isAutoplay || this.betControlsService.enable([u.w.BalloonTake])
                }
                statusPauseGame() {
                    this.startTimeoutViewKeep(!1), this.startAutoCashout(), this.soundService.stopSound(a.pD.balloonFly), this.soundService.playSound(a.pD.balloonAutoCashoutCountdown)
                }
                statusBonusGame() {
                    this.soundService.stopSound(a.pD.balloonFly), this.soundService.stopSound(a.pD.balloonAutoCashoutCountdown), this.soundService.pauseMusic(a.J9.balloonBgMusic), this.soundService.playSound(a.pD.balloonAchieveBonus), this.soundService.playMusic(a.J9.balloonBgMusicBonusGame), this.betControlsService.disable([u.w.BalloonHeat, u.w.BalloonTake])
                }
                statusBeforeEndGame() {
                    var t;
                    this.soundService.stopSound(a.pD.balloonFly), this.soundService.stopSound(a.pD.balloonAutoCashoutCountdown), null === (t = this.timerAutoCashout$) || void 0 === t || t.unsubscribe(), this.betControlsService.disable([u.w.BalloonTake, u.w.BalloonHeat])
                }
                statusEndGame() {
                    this.soundService.stopSound(a.pD.balloonAmb), this.isFirstProgressGame = !0, this.startTimeoutViewKeep(!1), this.betControlTake = 0, this.betControlsService.autoplay.isActive ? this.betControlsService.disable([u.w.Autoplay]) : (this.betControlsService.enable([u.w.BetInput, u.w.Autoplay, u.w.BalloonHeat]), this.betControlsService.disable([u.w.BalloonTake]), this.dataHeatDefault())
                }
                dataHeatDefault() {
                    this.dataHeat.text = this.translocoService.translate("shared.Press to bet!"), this.dataHeat.status = this.status, this.dataHeat.startAnim = null
                }
                subscribeBetControls() {
                    this.betControlsService.onAction$.pipe((0, B.h)(t => t.name == u.w.BalloonTake), (0, m.t)(this)).subscribe(() => {
                        this.soundService.playSound(a.pD.balloonTake), this.makeCashout()
                    }), this.betControlsService.onAction$.pipe((0, B.h)(t => t.name == u.w.Autoplay), (0, m.t)(this)).subscribe(t => {
                        if (this.coreService.isBalanceInsufficientForBet(this.betControlsService.betAmount)) return this.betControlsService.autoplayHandler(null), this.betControlsService.enable([u.w.Autoplay]), void this.toast.showError(this.translocoService.translate("shared.balance_not_enough"));
                        this.isAutoplay = !0, this.step = 0, this.balloonTarget = t.data.balloonTarget, this.betControlsService.disable([u.w.BalloonHeat, u.w.BetInput]), this.makeAutoplayBet(this.balloonTarget)
                    }), this.mousedown$ = this.betControlsService.onDown$.pipe((0, B.h)(t => t.name == u.w.BalloonHeat), (0, m.t)(this)), this.mouseup$ = this.betControlsService.onUp$.pipe((0, B.h)(t => t.name == u.w.BalloonHeat), (0, m.t)(this)), this.mouseup$.pipe((0, m.t)(this)).subscribe(() => {
                        this.lastMouseUpTimestamp = Date.now(), this.status !== n.Sv.EndGame && this.status !== n.Sv.BonusGame && this.status !== n.Sv.StartGame && (this.status = n.Sv.PauseGame)
                    }), this.mousedown$.pipe((0, m.t)(this)).subscribe(() => {
                        if (this.lastMouseDownTimestamp = Date.now(), this.status === n.Sv.Init || this.status === n.Sv.EndGame) return this.dataHeat.text = this.translocoService.translate("shared.Pre-heating balloon..."), this.dataHeat.startAnim = "keep", this.initCyclCoef(), this.status = n.Sv.StartGame, this.soundService.playSound(a.pD.buttonClick), this.disableBtnBetService.initDisable(), this.subscribeForkBetResponseAndTimer(), void this.makeBet();
                        this.status !== n.Sv.StartGame && (this.status === n.Sv.PauseGame || this.status === n.Sv.ProgressGame) && (this.status = n.Sv.ProgressGame, this.makeGameAction())
                    })
                }
                subscribeForkBetResponseAndTimer() {
                    (0, Z.D)([(0, G.H)(n.L3.delay.startGameMouseDown), this.connectorService.response(w.E.Bet).pipe((0, x.q)(1))]).pipe((0, m.t)(this)).subscribe({
                        next: ([, t]) => {
                            if (200 !== t.code) return this.ifcSeenderService.startRound(t), this.betControlsService.errorBetResponse(), void(this.status = n.Sv.EndGame);
                            this.ifcApiService.emitEvent(p.g.MakeBetComplete, {
                                id: 1,
                                code: t.code,
                                errorMessage: t.errorMessage,
                                additionalOperatorData: t.additionalOperatorData
                            }), this.ifcApiService.emitEvent(p.g.StartRound, {
                                bets: [{
                                    id: 1,
                                    amount: t.winAmount
                                }]
                            }), this.connectorService.request(y.T.GameAction, null)
                        }
                    })
                }
                subscribeAutoplayBetResponse() {
                    this.connectorService.response(w.E.AutoPlay).pipe((0, m.t)(this)).subscribe(t => {
                        if (200 !== t.code) return this.ifcSeenderService.startRound(t), this.betControlsService.errorBetResponse(), void(this.status = n.Sv.EndGame);
                        this.step = 0, this.ifcSeenderService.startRound(t.endGame), t.endGame.win && this.ifcApiService.emitEvent(p.g.Cashout, {
                            id: 1
                        }), this.isBonusGame = t.endGame.hasOwnProperty("fullFill") ? t.endGame.fullFill ? n.my.Yes : n.my.Fake : n.my.No, this.status = n.Sv.StartGame, this.status = n.Sv.ProgressGame, this.cycleAutoplayGameAction(t)
                    })
                }
                subscribeGameActionResponse() {
                    this.connectorService.response(w.E.GameAction).pipe((0, H.g)(n.L3.delay.intervalRequest - 50), (0, m.t)(this)).subscribe(t => {
                        if (this.gameActionWaitSendStatus = !1, 200 !== t.code) return this.betControlsService.errorBetResponse(), void(this.status = n.Sv.EndGame);
                        this.status === n.Sv.StartGame && (this.status = this.lastMouseDownTimestamp > this.lastMouseUpTimestamp ? n.Sv.ProgressGame : n.Sv.PauseGame), this.cycleGameAction(t)
                    })
                }
                subscribeCashoutResponse() {
                    this.connectorService.response(w.E.CashOut).pipe((0, m.t)(this)).subscribe(t => {
                        this.endGameBefore(t)
                    })
                }
                makeBet() {
                    if (this.coreService.isBalanceInsufficientForBet(this.betControlsService.betAmount)) return this.status = n.Sv.EndGame, void this.toast.showError(this.translocoService.translate("shared.balance_not_enough"));
                    const t = this.betControlsService.adjustBet();
                    this.ifcSeenderService.makeBet(t);
                    const o = this.coreService.invokeStartRound(t);
                    this.connectorService.request(y.T.Bet, o)
                }
                makeAutoplayBet(t) {
                    const o = this.betControlsService.adjustBet(),
                        c = this.coreService.invokeStartRound(o, {
                            autoPlayCoefficient: t
                        });
                    this.connectorService.request(y.T.AutoPlay, c)
                }
                makeGameAction() {
                    this.gameActionWaitSendStatus || (this.connectorService.request(y.T.GameAction, null), this.gameActionWaitSendStatus = !0)
                }
                makeCashout() {
                    this.status === n.Sv.BeforeEndGame || this.status === n.Sv.EndGame || this.status === n.Sv.BonusGame || (this.ifcApiService.emitEvent(p.g.Cashout, {
                        id: 1
                    }), this.status = n.Sv.BeforeEndGame, this.connectorService.request(y.T.CashOut, null))
                }
                cycleAutoplayGameAction(t) {
                    return (0, h.mG)(this, void 0, void 0, function*() {
                        this.step = this.step + 1;
                        const o = (0, N.A)(this.step * n.L3.delay.intervalRequest, this.gameConfig.timeFactor);
                        if (o >= t.endGame.target) return yield this.cycleGameAction({
                            currentCoefficient: t.endGame.target,
                            currentWinAmount: t.endGame.betAmount * t.endGame.target,
                            win: !0,
                            code: 200
                        }), void this.cycleGameAction(t);
                        this.cycleGameAction({
                            currentCoefficient: o,
                            currentWinAmount: t.endGame.betAmount * o,
                            win: !0,
                            code: 200
                        }), yield(0, b.V)(n.L3.delay.intervalRequest), this.cycleAutoplayGameAction(t)
                    })
                }
                cycleGameAction(t) {
                    return (0, h.mG)(this, void 0, void 0, function*() {
                        1 === t.currentCoefficient && !0 === t.win && this.soundService.playSound(a.pD.balloonTakeOff), t.hasOwnProperty("endGame") ? this.endGameBefore(t.endGame) : (this.updateGame(t), this.isAutoplay || this.betControlsService.enable([u.w.BalloonTake]), this.status === n.Sv.ProgressGame && (this.isAutoplay || this.makeGameAction()))
                    })
                }
                startBonusGame(t) {
                    return (0, h.mG)(this, void 0, void 0, function*() {
                        this.status = n.Sv.BonusGame, this.coefficients.currentCoefficient = t.win || this.isBonusGame !== n.my.Yes ? t.target : 0, this.bonusCoefficients = t.bonusCoefficients, t.fullFill ? yield(0, b.V)((0, n.ms)(t.bonusCoefficients.length)): yield(0, b.V)(n.L3.delay.startBonusGameFirst), this.isAutoplay || this.betControlsService.enable([u.w.BalloonHeat])
                    })
                }
                updateGame(t) {
                    this.coefficients.currentCoefficient = t.currentCoefficient, this.betControlTake = t.currentWinAmount
                }
                endGameBefore(t) {
                    return (0, h.mG)(this, void 0, void 0, function*() {
                        this.cashOutResponse = t, t.hasOwnProperty("fullFill") ? (this.isBonusGame = t.fullFill ? n.my.Yes : n.my.Fake, yield this.startBonusGame(t)) : this.isBonusGame = n.my.No, this.status !== n.Sv.BeforeEndGame && (this.status = n.Sv.BeforeEndGame), this.winGame = t.win ? n.Kr.Win : n.Kr.Lose, t.hasOwnProperty("fullFill") && t.fullFill ? (this.soundService.playSound(a.pD.balloonSumCounter), yield(0, b.V)(n.L3.delay.beforeEndGameFirst), this.soundService.stopSound(a.pD.balloonSumCounter), this.soundService.playSound(a.pD.balloonWin)) : (t.hasOwnProperty("fullFill") && !t.fullFill && this.soundService.playSound(a.pD.balloonBonusDeflate), !t.win && 0 === t.winAmount && this.soundService.playSound(a.pD.balloonBlast), t.win && this.soundService.playSound(a.pD.balloonWin))
                    })
                }
                endGameAfter() {
                    return (0, h.mG)(this, void 0, void 0, function*() {
                        this.isBonusGame !== n.my.No && (this.soundService.stopMusic(a.J9.balloonBgMusicBonusGame), this.soundService.playMusic(a.J9.balloonBgMusic)), yield(0, b.V)(this.coreService.config.minRoundDurationInMillis), this.winGame = n.Kr.Init, this.coefficients.currentCoefficient = 0, this.coefficients.bonusCoefficients = 0, this.updateBonusCoefficient = 0, this.isBonusGame = n.my.No, this.sendIfcEndRound(this.cashOutResponse), this.betControlsService.autoplay.isActive ? (this.coreService.invokeEndRound(this.cashOutResponse, !this.isAutoplay), this.betControlsService.onBetResponse({
                            winAmount: this.cashOutResponse.winAmount,
                            win: this.cashOutResponse.win,
                            betAmount: this.cashOutResponse.betAmount
                        }), this.status = n.Sv.EndGame, this.betControlsService.autoplay.isActive && (this.config.isShowWinAmountUntilNextRound && (yield(0, b.V)(500)), this.makeAutoplayBet(this.balloonTarget))) : (this.isAutoplay = !1, this.status = n.Sv.EndGame, this.coreService.invokeEndRound(this.cashOutResponse, !this.isAutoplay)), this.cashOutResponse.win && this.soundService.playSound(a.pD.win)
                    })
                }
                sendIfcEndRound(t) {
                    t.win ? (this.ifcApiService.emitEvent(p.g.UpdateBalance, {
                        amount: t.balance
                    }), this.ifcApiService.emitEvent(p.g.WinInfo, {
                        id: 1,
                        amount: t.winAmount
                    }), this.ifcApiService.emitEvent(p.g.CashoutComplete, {
                        id: 1,
                        code: t.code,
                        errorMessage: t.errorMessage,
                        additionalOperatorData: t.additionalOperatorData
                    })) : this.ifcApiService.emitEvent(p.g.UpdateBalance, {
                        amount: t.balance
                    }), this.ifcApiService.emitEvent(p.g.EndRound)
                }
                updateBonusCoef(t) {
                    this.updateBonusCoefficient = t.coef, this.indexBonusCoefficient = t.index, this.coefficients.bonusCoefficients = this.coefficients.bonusCoefficients + t.coef
                }
                startAutoCashout() {
                    this.dataHeat.startAnim = "autoCashout", this.dataHeat.text = `${this.translocoService.translate("shared.Auto-cashout-in:")} ${n.L3.delay.autoCashout}`, this.timerAutoCashout$ = (0, G.H)(1e3, 1e3).pipe((0, O.U)(t => n.L3.delay.autoCashout - t - 1), (0, x.q)(n.L3.delay.autoCashout), (0, m.t)(this)).subscribe(t => {
                        this.dataHeat.text = `${this.translocoService.translate("shared.Auto-cashout-in:")} ${t}`, 0 === t && this.makeCashout()
                    })
                }
                initCyclCoef(t = !0) {
                    var o;
                    if (t) {
                        this.soundService.playSound(a.pD.balloonHeat);
                        const c = n.L3.delay.intervalRequest;
                        this.subscriptionCyclCoef = function F(i = 0, t = E.z) {
                            return i < 0 && (i = 0), (0, G.H)(i, i, t)
                        }(n.L3.delay.startGameMouseDown / c).pipe((0, O.U)(d => d / c), (0, x.q)(c), function V(...i) {
                            return function J(...i) {
                                const t = (0, W.yG)(i);
                                return (0, I.e)((o, s) => {
                                    (0, U.u)()((0, Y.D)([o, ...i], t)).subscribe(s)
                                })
                            }(...i)
                        }((0, D.of)(1)), (0, m.t)(this)).subscribe(d => {
                            this.coefficients.currentCoefficient = d
                        })
                    } else this.soundService.stopSound(a.pD.balloonHeat), null === (o = this.subscriptionCyclCoef) || void 0 === o || o.unsubscribe(), this.coefficients.currentCoefficient = 0, this.dataHeat.startAnim = null
                }
                startTimeoutViewKeep(t = !0) {
                    t && this.isFirstProgressGame ? (this.dataHeat.startAnim = "afterKeep", this.timeoutViewKeep = setTimeout(() => {
                        "afterKeep" === this.dataHeat.startAnim && (this.dataHeat.startAnim = null)
                    }, n.L3.delay.viewKeepAfterInit)) : (this.dataHeat.startAnim = null, clearTimeout(this.timeoutViewKeep))
                }
                ngOnDestroy() {
                    this.soundService.stopMusic(a.J9.balloonBgMusic), this.soundService.stopMusic(a.J9.balloonBgMusicBonusGame)
                }
            };
            C.\u0275fac = function(t) {
                return new(t || C)(e.Y36(z.l), e.Y36(A.p), e.Y36($.v), e.Y36(P.Vn), e.Y36(a.yu), e.Y36(k.i), e.Y36(j.k), e.Y36(K.a), e.Y36(q.S), e.Y36(Q.h))
            }, C.\u0275cmp = e.Xpm({
                type: C,
                selectors: [
                    ["app-balloon"]
                ],
                decls: 5,
                vars: 17,
                consts: [
                    [1, "balloon"],
                    [3, "status", "winGame", "coefficients", "isBonusGame"],
                    [3, "winGame", "status", "isBonusGame"],
                    [3, "coefficients", "winGame", "updateBonusCoefficient", "status", "isBonusGame", "indexBonusCoefficient", "endGameAfter"],
                    [3, "isBonusGame", "coefficients", "bonusCoefficients", "status", "updateBonusCoef"]
                ],
                template: function(t, o) {
                    1 & t && (e.TgZ(0, "div", 0), e._UZ(1, "app-background", 1), e._UZ(2, "app-air-balloon", 2), e.TgZ(3, "app-coefficient", 3), e.NdJ("endGameAfter", function() {
                        return o.endGameAfter()
                    }), e.qZA(), e.TgZ(4, "app-bonus-game", 4), e.NdJ("updateBonusCoef", function(c) {
                        return o.updateBonusCoef(c)
                    }), e.qZA(), e.qZA()), 2 & t && (e.xp6(1), e.Q6J("status", o.status)("winGame", o.winGame)("coefficients", o.coefficients)("isBonusGame", o.isBonusGame), e.xp6(1), e.Q6J("winGame", o.winGame)("status", o.status)("isBonusGame", o.isBonusGame), e.xp6(1), e.Q6J("coefficients", o.coefficients)("winGame", o.winGame)("updateBonusCoefficient", o.updateBonusCoefficient)("status", o.status)("isBonusGame", o.isBonusGame)("indexBonusCoefficient", o.indexBonusCoefficient), e.xp6(1), e.Q6J("isBonusGame", o.isBonusGame)("coefficients", o.coefficients)("bonusCoefficients", o.bonusCoefficients)("status", o.status))
                },
                directives: [oe, ie, le, v],
                styles: ["[_nghost-%COMP%]{position:absolute;top:0;left:0;display:flex;width:100%;height:100%}.balloon[_ngcontent-%COMP%]{flex-grow:1;display:flex}"]
            }), C = (0, h.gn)([(0, m.c)()], C);
            let fe = (() => {
                    class i {}
                    return i.\u0275fac = function(o) {
                        return new(o || i)
                    }, i.\u0275mod = e.oAB({
                        type: i
                    }), i.\u0275inj = e.cJS({
                        imports: [
                            [f.ez, S._J]
                        ]
                    }), i
                })(),
                pe = (() => {
                    class i {}
                    return i.\u0275fac = function(o) {
                        return new(o || i)
                    }, i.\u0275mod = e.oAB({
                        type: i
                    }), i.\u0275inj = e.cJS({
                        imports: [
                            [f.ez]
                        ]
                    }), i
                })();
            const de = [{
                path: "",
                component: C
            }];
            let he = (() => {
                class i {}
                return i.\u0275fac = function(o) {
                    return new(o || i)
                }, i.\u0275mod = e.oAB({
                    type: i
                }), i.\u0275inj = e.cJS({
                    imports: [
                        [f.ez, L.Bz.forChild(de), R, T, fe, pe, P.y4]
                    ]
                }), i
            })()
        }
    }
]);