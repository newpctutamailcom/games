(() => {
    "use strict";
    var e, v = {},
        g = {};

    function r(e) {
        var n = g[e];
        if (void 0 !== n) return n.exports;
        var t = g[e] = {
            id: e,
            loaded: !1,
            exports: {}
        };
        return v[e].call(t.exports, t, t.exports, r), t.loaded = !0, t.exports
    }
    r.m = v, e = [], r.O = (n, t, i, o) => {
        if (!t) {
            var a = 1 / 0;
            for (f = 0; f < e.length; f++) {
                for (var [t, i, o] = e[f], u = !0, d = 0; d < t.length; d++)(!1 & o || a >= o) && Object.keys(r.O).every(p => r.O[p](t[d])) ? t.splice(d--, 1) : (u = !1, o < a && (a = o));
                if (u) {
                    e.splice(f--, 1);
                    var c = i();
                    void 0 !== c && (n = c)
                }
            }
            return n
        }
        o = o || 0;
        for (var f = e.length; f > 0 && e[f - 1][2] > o; f--) e[f] = e[f - 1];
        e[f] = [t, i, o]
    }, r.n = e => {
        var n = e && e.__esModule ? () => e.default : () => e;
        return r.d(n, {
            a: n
        }), n
    }, r.d = (e, n) => {
        for (var t in n) r.o(n, t) && !r.o(e, t) && Object.defineProperty(e, t, {
            enumerable: !0,
            get: n[t]
        })
    }, r.f = {}, r.e = e => Promise.all(Object.keys(r.f).reduce((n, t) => (r.f[t](e, n), n), [])), r.u = e => (592 === e ? "common" : e) + "." + {
        11: "33a8bcb8cb4b5f3a",
        17: "193f45a1692c06ae",
        80: "1eb5bc87f3297abd",
        116: "c692ef8071fcfb2c",
        171: "6a26927e32250a5a",
        396: "7a100d7d99cc7393",
        455: "84aa6bc697969cd9",
        592: "cd2c562b6d80f848",
        646: "fae3dece01ee872f",
        709: "800199dc3c1ebab2",
        794: "495d4b9b3eaa171f",
        850: "9296eed9aaa2743c",
        983: "94eb03ef67b45c1e"
    }[e] + ".js", r.miniCssF = e => {}, r.hmd = e => ((e = Object.create(e)).children || (e.children = []), Object.defineProperty(e, "exports", {
        enumerable: !0,
        set: () => {
            throw new Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: " + e.id)
        }
    }), e), r.o = (e, n) => Object.prototype.hasOwnProperty.call(e, n), (() => {
        var e = {},
            n = "ng-turbo-games:";
        r.l = (t, i, o, f) => {
            if (e[t]) e[t].push(i);
            else {
                var a, u;
                if (void 0 !== o)
                    for (var d = document.getElementsByTagName("script"), c = 0; c < d.length; c++) {
                        var s = d[c];
                        if (s.getAttribute("src") == t || s.getAttribute("data-webpack") == n + o) {
                            a = s;
                            break
                        }
                    }
                a || (u = !0, (a = document.createElement("script")).type = "module", a.charset = "utf-8", a.timeout = 120, r.nc && a.setAttribute("nonce", r.nc), a.setAttribute("data-webpack", n + o), a.src = r.tu(t)), e[t] = [i];
                var l = (m, p) => {
                        a.onerror = a.onload = null, clearTimeout(b);
                        var h = e[t];
                        if (delete e[t], a.parentNode && a.parentNode.removeChild(a), h && h.forEach(_ => _(p)), m) return m(p)
                    },
                    b = setTimeout(l.bind(null, void 0, {
                        type: "timeout",
                        target: a
                    }), 12e4);
                a.onerror = l.bind(null, a.onerror), a.onload = l.bind(null, a.onload), u && document.head.appendChild(a)
            }
        }
    })(), r.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, r.nmd = e => (e.paths = [], e.children || (e.children = []), e), (() => {
        var e;
        r.tt = () => (void 0 === e && (e = {
            createScriptURL: n => n
        }, "undefined" != typeof trustedTypes && trustedTypes.createPolicy && (e = trustedTypes.createPolicy("angular#bundler", e))), e)
    })(), r.tu = e => r.tt().createScriptURL(e), r.p = "", (() => {
        var e = {
            666: 0
        };
        r.f.j = (i, o) => {
            var f = r.o(e, i) ? e[i] : void 0;
            if (0 !== f)
                if (f) o.push(f[2]);
                else if (666 != i) {
                var a = new Promise((s, l) => f = e[i] = [s, l]);
                o.push(f[2] = a);
                var u = r.p + r.u(i),
                    d = new Error;
                r.l(u, s => {
                    if (r.o(e, i) && (0 !== (f = e[i]) && (e[i] = void 0), f)) {
                        var l = s && ("load" === s.type ? "missing" : s.type),
                            b = s && s.target && s.target.src;
                        d.message = "Loading chunk " + i + " failed.\n(" + l + ": " + b + ")", d.name = "ChunkLoadError", d.type = l, d.request = b, f[1](d)
                    }
                }, "chunk-" + i, i)
            } else e[i] = 0
        }, r.O.j = i => 0 === e[i];
        var n = (i, o) => {
                var d, c, [f, a, u] = o,
                    s = 0;
                if (f.some(b => 0 !== e[b])) {
                    for (d in a) r.o(a, d) && (r.m[d] = a[d]);
                    if (u) var l = u(r)
                }
                for (i && i(o); s < f.length; s++) r.o(e, c = f[s]) && e[c] && e[c][0](), e[c] = 0;
                return r.O(l)
            },
            t = self.webpackChunkng_turbo_games = self.webpackChunkng_turbo_games || [];
        t.forEach(n.bind(null, 0)), t.push = n.bind(null, t.push.bind(t))
    })()
})();