"use strict";
(self.webpackChunkng_turbo_games = self.webpackChunkng_turbo_games || []).push([
    [116], {
        5116: (dt, y, r) => {
            r.r(y), r.d(y, {
                DiceModule: () => ht
            });
            var h = r(9808),
                _ = r(4996),
                T = r(7303),
                D = r(5107),
                p = r(3075),
                v = r(6352),
                S = r(8721),
                V = r(3904),
                B = r(4364),
                t = r(7587);
            let U = (() => {
                class n {}
                return n.\u0275fac = function(e) {
                    return new(e || n)
                }, n.\u0275mod = t.oAB({
                    type: n
                }), n.\u0275inj = t.cJS({
                    imports: [
                        [h.ez, p.UX, p.u5, S.F, v.y4, V.T, B.D]
                    ]
                }), n
            })();
            var b = r(655),
                u = r(4987),
                E = r(9300),
                F = r(8044),
                k = r(4946),
                O = r(4750),
                R = r(1361),
                C = r(4431),
                c = r(2398),
                l = r(7258),
                I = r(3601),
                P = r(2821),
                M = r(8784),
                A = r(9798),
                W = r(4530);
            const Y = function(n) {
                    return {
                        "ui-state-disabled": n
                    }
                },
                j = function(n) {
                    return {
                        left: n
                    }
                };
            let H = (() => {
                class n {
                    constructor(e, s, o) {
                        this.el = e, this.renderer = s, this.ngZone = o, this.min = 0, this.max = 100, this.orientation = "horizontal", this.isFloor = !1, this.checkChange = new t.vpe, this.checkSlideEnd = new t.vpe, this.checkSlideStart = new t.vpe, this.handleValues = [], this.handleIndex = 0, this.onModelChange = () => {}, this.onModelTouched = () => {}
                    }
                    onMouseDown(e, s) {
                        this.disabled || (this.dragging = !0, this.updateDomData(), this.sliderHandleClick = !0, this.handleIndex = s, this.bindDragListeners(), this.checkSlideStart.emit({
                            originalEvent: e,
                            values: this.range ? this.values : this.value
                        }), e.preventDefault())
                    }
                    onTouchStart(e, s) {
                        const o = e.changedTouches[0];
                        this.startHandleValue = this.range ? this.handleValues[s] : this.handleValue, this.dragging = !0, this.handleIndex = s, "horizontal" === this.orientation ? (this.startx = parseInt(o.clientX, 10), this.barWidth = this.el.nativeElement.children[0].offsetWidth) : (this.starty = parseInt(o.clientY, 10), this.barHeight = this.el.nativeElement.children[0].offsetHeight), this.checkSlideStart.emit({
                            originalEvent: e,
                            values: this.range ? this.values : this.value
                        }), e.preventDefault()
                    }
                    onTouchMove(e) {
                        let s = e.changedTouches[0],
                            o = 0;
                        o = "horizontal" === this.orientation ? Math.floor(100 * (parseInt(s.clientX, 10) - this.startx) / this.barWidth) + this.startHandleValue : Math.floor(100 * (this.starty - parseInt(s.clientY, 10)) / this.barHeight) + this.startHandleValue, this.setValueFromHandle(e, o), e.preventDefault()
                    }
                    onTouchEnd(e) {
                        this.dragging = !1, this.checkSlideEnd.emit({
                            originalEvent: e,
                            values: this.range ? this.values : this.value
                        })
                    }
                    onBarClick(e) {
                        this.disabled || (this.sliderHandleClick || (this.updateDomData(), this.handleChange(e), this.checkSlideEnd.emit({
                            originalEvent: e,
                            values: this.range ? this.values : this.value
                        })), this.sliderHandleClick = !1)
                    }
                    handleChange(e) {
                        const s = this.calculateHandleValue(e);
                        this.setValueFromHandle(e, s)
                    }
                    bindDragListeners() {
                        this.ngZone.runOutsideAngular(() => {
                            this.dragListener || (this.dragListener = this.renderer.listen("document", "mousemove", e => {
                                this.dragging && this.ngZone.run(() => {
                                    this.handleChange(e)
                                })
                            })), this.mouseupListener || (this.mouseupListener = this.renderer.listen("document", "mouseup", e => {
                                this.dragging && (this.dragging = !1, this.ngZone.run(() => {
                                    this.checkSlideEnd.emit({
                                        originalEvent: e,
                                        values: this.range ? this.values : this.value
                                    })
                                })), this.unbindDragListeners()
                            }))
                        })
                    }
                    unbindDragListeners() {
                        this.dragListener && this.dragListener(), this.mouseupListener && this.mouseupListener(), this.dragListener = null, this.mouseupListener = null
                    }
                    setValueFromHandle(e, s) {
                        const o = this.getValueFromHandle(s);
                        this.range ? this.step ? this.handleStepChange(o, this.values[this.handleIndex]) : (this.handleValues[this.handleIndex] = s, this.updateValue(o, e)) : this.step ? this.handleStepChange(o, this.value) : (this.handleValue = s, this.updateValue(o, e))
                    }
                    handleStepChange(e, s) {
                        const o = e - s;
                        let a = s;
                        o < 0 ? a = s + Math.ceil((e - s) / this.step) * this.step : o > 0 && (a = s + Math.floor((e - s) / this.step) * this.step), this.updateValue(a), this.updateHandleValue()
                    }
                    writeValue(e) {
                        this.range ? this.values = e || [0, 0] : this.value = e || 0, this.updateHandleValue()
                    }
                    registerOnChange(e) {
                        this.onModelChange = e
                    }
                    registerOnTouched(e) {
                        this.onModelTouched = e
                    }
                    setDisabledState(e) {
                        this.disabled = e
                    }
                    isVertical() {
                        return "vertical" === this.orientation
                    }
                    updateDomData() {
                        const e = this.el.nativeElement.children[0].getBoundingClientRect();
                        this.initX = e.left + (window.pageXOffset || document.documentElement.scrollLeft) - (document.documentElement.clientLeft || 0), this.initY = e.top + (window.pageYOffset || document.documentElement.scrollTop) - (document.documentElement.clientTop || 0), this.barWidth = this.el.nativeElement.children[0].offsetWidth, this.barHeight = this.el.nativeElement.children[0].offsetHeight
                    }
                    calculateHandleValue(e) {
                        return "horizontal" === this.orientation ? 100 * (e.pageX - this.initX) / this.barWidth : 100 * (this.initY + this.barHeight - e.pageY) / this.barHeight
                    }
                    updateHandleValue() {
                        this.range ? (this.handleValues[0] = 100 * (this.values[0] < this.min ? 0 : this.values[0] - this.min) / (this.max - this.min), this.handleValues[1] = 100 * (this.values[1] > this.max ? 100 : this.values[1] - this.min) / (this.max - this.min)) : this.handleValue = this.value < this.min ? 0 : this.value > this.max ? 100 : 100 * (this.value - this.min) / (this.max - this.min)
                    }
                    updateValue(e, s) {
                        if (this.range) {
                            let o = e;
                            0 == this.handleIndex ? o < this.min ? (o = this.min, this.handleValues[0] = 0) : o > this.values[1] && (o = this.values[1], this.handleValues[0] = this.handleValues[1]) : o > this.max ? (o = this.max, this.handleValues[1] = 100) : o < this.values[0] && (o = this.values[0], this.handleValues[1] = this.handleValues[0]), this.values[this.handleIndex] = this.isFloor ? Math.floor(o) : o, this.onModelChange(this.values), this.checkChange.emit({
                                event: s,
                                values: this.values
                            })
                        } else e < this.min ? (e = this.min, this.handleValue = 0) : e > this.max && (e = this.max, this.handleValue = 100), this.value = this.isFloor ? Math.floor(e) : e, this.onModelChange(this.value), this.checkChange.emit({
                            event: s,
                            value: this.value
                        })
                    }
                    getValueFromHandle(e) {
                        return e / 100 * (this.max - this.min) + this.min
                    }
                    ngOnDestroy() {
                        this.unbindDragListeners()
                    }
                }
                return n.\u0275fac = function(e) {
                    return new(e || n)(t.Y36(t.SBq), t.Y36(t.Qsj), t.Y36(t.R0b))
                }, n.\u0275cmp = t.Xpm({
                    type: n,
                    selectors: [
                        ["app-ui-slider"]
                    ],
                    inputs: {
                        animate: "animate",
                        disabled: "disabled",
                        min: "min",
                        max: "max",
                        orientation: "orientation",
                        step: "step",
                        range: "range",
                        isFloor: "isFloor"
                    },
                    outputs: {
                        checkChange: "checkChange",
                        checkSlideEnd: "checkSlideEnd",
                        checkSlideStart: "checkSlideStart"
                    },
                    features: [t._Bn([{
                        provide: p.JU,
                        useExisting: (0, t.Gpc)(() => n),
                        multi: !0
                    }])],
                    decls: 2,
                    vars: 8,
                    consts: [
                        [1, "bet-control-slider", 3, "ngClass", "click"],
                        [1, "ui-slider-handle", "btn", "btn-game", 3, "ngStyle", "mousedown", "touchstart", "touchmove", "touchend"]
                    ],
                    template: function(e, s) {
                        1 & e && (t.TgZ(0, "div", 0), t.NdJ("click", function(a) {
                            return s.onBarClick(a)
                        }), t.TgZ(1, "span", 1), t.NdJ("mousedown", function(a) {
                            return s.onMouseDown(a)
                        })("touchstart", function(a) {
                            return s.onTouchStart(a)
                        })("touchmove", function(a) {
                            return s.onTouchMove(a)
                        })("touchend", function(a) {
                            return s.onTouchEnd(a)
                        }), t.qZA(), t.qZA()), 2 & e && (t.Q6J("ngClass", t.VKq(4, Y, s.disabled)), t.xp6(1), t.Udp("transition", s.dragging ? "none" : null), t.Q6J("ngStyle", t.VKq(6, j, s.handleValue + "%")))
                    },
                    directives: [h.mk, h.PC],
                    styles: ['[_nghost-%COMP%]{width:100%}.bet-control-slider[_ngcontent-%COMP%]{width:calc(100% - 30px);margin:0 auto;min-width:1px;background:rgba(0,0,0,.4);border:1px solid rgba(255,255,255,.2);box-shadow:inset 0 1px #00000080;border-radius:12px;height:14px;position:relative}.bet-control-slider[_ngcontent-%COMP%]:after{width:calc(100% - 10px);margin-left:5px;bottom:-7px;left:0;height:6px;content:" ";position:absolute;background:repeating-linear-gradient(to left,rgba(255,255,255,.2) 0,rgba(255,255,255,.2) 1px,transparent 1px,transparent 5px);z-index:0}.bet-control-slider.ui-state-disabled[_ngcontent-%COMP%]{opacity:.3}.bet-control-slider[_ngcontent-%COMP%]   .ui-slider-handle[_ngcontent-%COMP%]{position:absolute;width:30px;height:30px;cursor:default;touch-action:none;z-index:1;top:-10px;margin-left:-15px;transition:left .6s ease}.bet-control-slider[_ngcontent-%COMP%]   .ui-slider-handle[_ngcontent-%COMP%]:after{content:" ";position:absolute;width:18px;height:13px;background:url(icon-slider.3c6df42e645d3807.svg) no-repeat;top:50%;left:50%;transform:translate(-50%,-50%)}']
                }), n
            })();
            var q = r(1560),
                z = r(8855);

            function J(n, i) {
                if (1 & n && (t.ynx(0), t._uU(1), t.BQk()), 2 & n) {
                    const e = t.oxw().$implicit;
                    t.xp6(1), t.hij(" (", e("shared.max"), ") ")
                }
            }

            function Q(n, i) {
                if (1 & n && (t.TgZ(0, "div", 21), t._uU(1), t.ALo(2, "decimalMultiplier"), t.qZA()), 2 & n) {
                    const e = t.oxw(2);
                    t.xp6(1), t.hij(" ", t.lcZ(2, 1, e.payoutMax), " x ")
                }
            }

            function G(n, i) {
                if (1 & n && (t.ynx(0), t.TgZ(1, "label"), t._uU(2), t.qZA(), t.TgZ(3, "span"), t._uU(4), t.ALo(5, "decimalCurrency"), t.TgZ(6, "span"), t._uU(7), t.qZA(), t.qZA(), t.BQk()), 2 & n) {
                    const e = t.oxw().$implicit,
                        s = t.oxw();
                    t.xp6(2), t.hij("", e("shared.Potential-win"), ":"), t.xp6(2), t.hij(" ", t.lcZ(5, 3, s.profit), " "), t.xp6(3), t.Oqu(s.config.currency)
                }
            }

            function $(n, i) {
                if (1 & n && (t.TgZ(0, "label"), t._uU(1), t.qZA(), t.TgZ(2, "span"), t._uU(3), t.ALo(4, "decimalCurrency"), t.TgZ(5, "span"), t._uU(6), t.qZA(), t.qZA()), 2 & n) {
                    const e = t.oxw().$implicit,
                        s = t.oxw();
                    t.xp6(1), t.hij("", e("shared.Max-win"), ":"), t.xp6(2), t.hij(" ", t.lcZ(4, 3, s.config.maxUserWin), " "), t.xp6(3), t.Oqu(s.config.currency)
                }
            }

            function X(n, i) {
                if (1 & n && (t.ynx(0), t.TgZ(1, "div", 1), t.TgZ(2, "div", 2), t.TgZ(3, "div", 3), t.TgZ(4, "label"), t.ALo(5, "async"), t._uU(6), t.YNc(7, J, 2, 1, "ng-container", 4), t.ALo(8, "async"), t.qZA(), t.TgZ(9, "div", 5), t.TgZ(10, "app-spinner", 6), t.TgZ(11, "div", 7), t.TgZ(12, "div", 8, 9), t.YNc(14, Q, 3, 3, "div", 10), t.ALo(15, "async"), t.TgZ(16, "div", 11, 12), t.TgZ(18, "span", 13), t._uU(19, " x "), t.qZA(), t.qZA(), t.qZA(), t.qZA(), t.qZA(), t.qZA(), t.qZA(), t.TgZ(20, "div", 14), t._UZ(21, "app-ui-slider", 15), t.qZA(), t.qZA(), t.TgZ(22, "div", 16), t.TgZ(23, "div", 17), t.YNc(24, G, 8, 5, "ng-container", 18), t.YNc(25, $, 7, 5, "ng-template", null, 19, t.W1O), t.qZA(), t.TgZ(27, "div", 20), t.TgZ(28, "label"), t._uU(29), t.qZA(), t.TgZ(30, "span"), t._uU(31), t.ALo(32, "decimalMultiplier"), t.TgZ(33, "span"), t._uU(34, "%"), t.qZA(), t.qZA(), t.qZA(), t.qZA(), t.qZA(), t.BQk()), 2 & n) {
                    const e = i.$implicit,
                        s = t.MAs(26),
                        o = t.oxw();
                    t.xp6(1), t.Q6J("ngClass", o.diceControlsClasses), t.xp6(3), t.ekj("white-text", t.lcZ(5, 17, o.maxWinService.isMaxUserWin$) && o.config.isMaxWinAm), t.xp6(2), t.hij(" ", e("shared.Payout"), " "), t.xp6(1), t.Q6J("ngIf", t.lcZ(8, 19, o.maxWinService.isMaxUserWin$) && o.config.isMaxWinAm), t.xp6(3), t.Q6J("formControl", o.formControlPayout)("max", o.gameConfig.payout.max)("min", o.gameConfig.payout.min)("formatPrecision", o.gameConfig.payout.precision), t.xp6(4), t.Q6J("ngIf", t.lcZ(15, 21, o.maxWinService.isMaxUserWin$) && o.config.isMaxWinAm), t.xp6(7), t.Q6J("formControl", o.formControlSlider)("min", o.gameConfig.roll.min)("max", o.gameConfig.roll.max), t.xp6(3), t.Q6J("ngIf", !o.config.isMaxWinAm || o.config.isMaxWinAm && o.profit <= o.config.maxUserWin)("ngIfElse", s), t.xp6(5), t.hij("", e("shared.Chance"), ":"), t.xp6(2), t.hij(" ", t.lcZ(32, 23, o.winChance), " ")
                }
            }
            let d = class {
                constructor(i, e, s, o) {
                    this.coreService = i, this.betControlsService = e, this.soundService = s, this.maxWinService = o, this.betAmount = 0, this.onChange = new t.vpe, this.checkProfit = new t.vpe, this.formControlSlider = new p.NI(0), this.formControlPayout = new p.NI, this.profit = 0, this.isPlayBallDrag = !1, this.oldProfit = this.profit, this.ignorePlayBallDrag = 2, this.reverseValue = (a, g, f) => {
                        const x = function N(n, i, e) {
                            return new l.t(l.t.sub(n, i)).div(l.t.sub(e, i)).times(100).toNumber()
                        }(a, g, f);
                        return function L(n, i, e) {
                            return new l.t(l.t.sub(e, i)).div(100).times(n).plus(i).toNumber()
                        }(l.t.sub(100, x).toNumber(), g, f)
                    }
                }
                ngOnInit() {
                    this.subscribeClaim(), this.formControlSlider.valueChanges.pipe((0, I.e)(50), (0, u.t)(this)).subscribe(() => {
                        this.updateProfit(), this.formControlPayout.setValue(this.payOut, {
                            emitEvent: !1
                        }), this.onChange.emit(this.rollValues)
                    }), this.formControlPayout.valueChanges.pipe((0, u.t)(this)).subscribe(i => {
                        this.onChangePayout(i)
                    }), this.formControlPayout.setValue(2)
                }
                ngOnChanges(i) {
                    i.betAmount && this.updateProfit(), i.isDisabled && this.changeDisabled()
                }
                get payoutMax() {
                    return this.coreService.freeBets.activeFreeBet ? l.t.div(this.config.maxUserWin, this.coreService.freeBets.activeFreeBet.betAmount).plus(1).toFixed(2, l.t.ROUND_DOWN) : l.t.div(this.config.maxUserWin, this.betControlsService.betAmount).toFixed(2, l.t.ROUND_DOWN)
                }
                subscribeClaim() {
                    this.betControlsService.onClaim$.pipe((0, u.t)(this)).subscribe(() => {
                        this.updateProfit()
                    })
                }
                onChangePayout(i) {
                    const e = this.payoutToUnder(i);
                    this.formControlSlider.setValue(this.reverseValue(e, this.gameConfig.roll.min, this.gameConfig.roll.max), {
                        emitEvent: !1
                    }), this.updateProfit(), this.onChange.emit(this.rollValues)
                }
                get rollValues() {
                    let i = this.reverseValue(this.formControlSlider.value, this.gameConfig.roll.min, this.gameConfig.roll.max),
                        e = l.t.sub(99.99, i).toNumber();
                    return {
                        under: new l.t(i).toFixed(this.gameConfig.roll.precision, l.t.ROUND_DOWN),
                        over: new l.t(e).toFixed(this.gameConfig.roll.precision, l.t.ROUND_DOWN)
                    }
                }
                get payOut() {
                    return (100 - this.config.houseEdge) / +this.rollValues.under
                }
                get winChance() {
                    return this.rollValues.under
                }
                payoutToUnder(i) {
                    return (100 - this.config.houseEdge) / i
                }
                updateProfit() {
                    this.oldProfit = this.profit;
                    const i = +this.payOut;
                    if (i !== 1 / 0 && i !== -1 / 0) {
                        if (this.coreService.freeBets.activeFreeBet) return this.profit = l.t.mul(this.coreService.freeBets.activeFreeBet.betAmount, i).sub(this.coreService.freeBets.activeFreeBet.betAmount).toNumber(), void this.checkProfit.emit(+this.profit);
                        this.profit = l.t.mul(this.betAmount, i).toNumber(), this.checkProfit.emit(+this.profit)
                    }
                    this.profit !== this.oldProfit && (0 === this.ignorePlayBallDrag ? this.playBallDrag() : --this.ignorePlayBallDrag)
                }
                playBallDrag() {
                    this.isPlayBallDrag || (this.isPlayBallDrag = !0, this.soundService.playSound(C.pD.diceBallDrag), setTimeout(() => {
                        this.isPlayBallDrag = !1
                    }, 50))
                }
                changeDisabled() {
                    this.isDisabled ? (this.diceControlsClasses = "dice-controls_disabled", this.formControlPayout.disable(), this.formControlSlider.disable()) : (this.diceControlsClasses = "", this.formControlPayout.enable(), this.formControlSlider.enable())
                }
                ngOnDestroy() {}
            };
            d.\u0275fac = function(i) {
                return new(i || d)(t.Y36(P.p), t.Y36(M.l), t.Y36(C.yu), t.Y36(A.a))
            }, d.\u0275cmp = t.Xpm({
                type: d,
                selectors: [
                    ["app-controls"]
                ],
                inputs: {
                    config: "config",
                    gameConfig: "gameConfig",
                    betAmount: "betAmount",
                    isDisabled: "isDisabled"
                },
                outputs: {
                    onChange: "onChange",
                    checkProfit: "checkProfit"
                },
                features: [t.TTD],
                decls: 1,
                vars: 0,
                consts: [
                    [4, "transloco"],
                    [1, "dice-controls", 3, "ngClass"],
                    [1, "row", "no-gutters", "c-main"],
                    [1, "col-5", "text-center", "c-payout"],
                    [4, "ngIf"],
                    [1, "w-100"],
                    [3, "formControl", "max", "min", "formatPrecision"],
                    [1, "w-100", "d-flex", "justify-content-center"],
                    [1, "c-payout-value"],
                    ["inputFieldTrigger", ""],
                    ["class", "input-mask", 4, "ngIf"],
                    [1, "input"],
                    ["inputField", ""],
                    [1, "font-weight-normal", "d-inline-block", "align-top"],
                    [1, "col-7", "text-center", "c-slider"],
                    [3, "formControl", "min", "max"],
                    [1, "row", "no-gutters", "c-footer"],
                    [1, "col-6", "col-md-5", "c-potential-win"],
                    [4, "ngIf", "ngIfElse"],
                    ["maxWin", ""],
                    [1, "col-6", "col-md-7", "c-chance"],
                    [1, "input-mask"]
                ],
                template: function(i, e) {
                    1 & i && t.YNc(0, X, 35, 25, "ng-container", 0)
                },
                directives: [v.KI, h.mk, h.O5, W.O, p.JJ, p.oH, H],
                pipes: [h.Ov, q.q, z.P],
                styles: ["[_nghost-%COMP%]{width:100%;display:flex;justify-content:center}.dice-controls[_ngcontent-%COMP%]{background:rgba(0,0,0,.3);border:1px solid #1e1e1e;border-radius:8px;width:100%;min-width:300px;max-width:500px;height:100px}.dice-controls_disabled[_ngcontent-%COMP%]{pointer-events:none}.c-main[_ngcontent-%COMP%]{height:62px}.c-main[_ngcontent-%COMP%]   .c-payout[_ngcontent-%COMP%]{display:flex;flex-direction:column;justify-content:center;align-items:center}.c-main[_ngcontent-%COMP%]   .c-payout[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]{font-size:12px;margin:0}.c-main[_ngcontent-%COMP%]   .c-payout[_ngcontent-%COMP%]   .c-payout-value[_ngcontent-%COMP%]{position:relative;background:rgba(0,0,0,.4);border:1px solid rgba(255,255,255,.2);box-shadow:inset 0 1px #00000080;border-radius:14px;height:28px;max-width:100px;width:100%;color:#fff;font-size:20px;display:flex;justify-content:center;align-items:center;cursor:text}.c-main[_ngcontent-%COMP%]   .c-payout[_ngcontent-%COMP%]   .c-payout-value[_ngcontent-%COMP%]   .input[_ngcontent-%COMP%]{height:20px;line-height:1;width:100%}.c-main[_ngcontent-%COMP%]   .c-payout[_ngcontent-%COMP%]   .c-payout-value[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:18px;margin:0 5px}.c-footer[_ngcontent-%COMP%]{background:rgba(0,0,0,.4);border-bottom-left-radius:8px;border-bottom-right-radius:8px;height:38px}.c-slider[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center}.c-potential-win[_ngcontent-%COMP%], .c-chance[_ngcontent-%COMP%]{display:flex;justify-content:center;align-items:center;flex-direction:column}.c-potential-win[_ngcontent-%COMP%]   label[_ngcontent-%COMP%], .c-chance[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]{margin-bottom:2px;font-size:12px;line-height:12px}.c-potential-win[_ngcontent-%COMP%]   span[_ngcontent-%COMP%], .c-chance[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:14px;line-height:14px;color:#fff}.c-chance[_ngcontent-%COMP%]{flex-direction:row}.c-chance[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]{margin-bottom:0;margin-right:8px}.white-text[_ngcontent-%COMP%]{color:#fff}.input-mask[_ngcontent-%COMP%]{position:absolute;z-index:1;top:0;left:0;display:flex;align-items:center;justify-content:center;width:100%;height:100%;border-radius:14px;border:1px solid #fff;background-color:#b32b00}"]
            }), d = (0, b.gn)([(0, u.c)()], d);
            let K = (() => {
                class n {
                    constructor(e, s, o) {
                        this.el = e, this.zone = s, this.renderer = o, this.duration = 500, this.precision = 0, this.isAddClassOnAnimationEnd = !1, this._fps = 60, this.timeStep = 1e3 / this._fps, this.count = a => {
                            this.startTime || (this.startTime = a, this.previousTimeStamp = a);
                            const g = (a - this.startTime) / this.duration >= 1 ? 1 : (a - this.startTime) / this.duration,
                                f = this.previousValue + (this.digit - this.previousValue) * g;
                            g < 1 ? (a - this.previousTimeStamp >= this.timeStep && (this.el.nativeElement.textContent = this.formatValue(f), this.previousTimeStamp = a), this.requestAnimationFrameId = requestAnimationFrame(this.count)) : 1 === g && (this.el.nativeElement.textContent = this.formatValue(f), this.classOnAnimationEnd && this.isAddClassOnAnimationEnd && this.renderer.addClass(this.el.nativeElement, this.classOnAnimationEnd))
                        }
                    }
                    get fps() {
                        return this._fps
                    }
                    set fps(e) {
                        void 0 !== e && (this._fps = e, this.timeStep = 1e3 / this._fps)
                    }
                    ngOnInit() {
                        this.el.nativeElement.textContent = this.formatValue(this.digit)
                    }
                    ngOnChanges(e) {
                        e.digit && e.digit.previousValue && this.animateCount(e)
                    }
                    formatValue(e) {
                        return this.numberLength ? ("" + e.toFixed(this.precision)).padStart(this.numberLength, "0") : "" + e.toFixed(this.precision)
                    }
                    animateCount(e) {
                        this.zone.runOutsideAngular(() => {
                            this.duration || (this.duration = 500), this.classOnAnimationEnd && this.renderer.removeClass(this.el.nativeElement, this.classOnAnimationEnd), "number" == typeof this.digit && (this.startTime = null, this.previousTimeStamp = null, this.previousValue = e.digit.previousValue, this.requestAnimationFrameId = requestAnimationFrame(this.count))
                        })
                    }
                    ngOnDestroy() {
                        cancelAnimationFrame(this.requestAnimationFrameId)
                    }
                }
                return n.\u0275fac = function(e) {
                    return new(e || n)(t.Y36(t.SBq), t.Y36(t.R0b), t.Y36(t.Qsj))
                }, n.\u0275dir = t.lG2({
                    type: n,
                    selectors: [
                        ["", "appAnimatedDigit", ""]
                    ],
                    inputs: {
                        duration: "duration",
                        digit: "digit",
                        precision: "precision",
                        fps: "fps",
                        classOnAnimationEnd: "classOnAnimationEnd",
                        isAddClassOnAnimationEnd: "isAddClassOnAnimationEnd",
                        numberLength: "numberLength"
                    },
                    features: [t.TTD]
                }), n
            })();
            const tt = ["diceResultPointRef"];
            let w = (() => {
                class n {
                    constructor() {
                        this.rollNumber = 50, this.win = !1, this.overDisabled = !1, this.underDisabled = !1
                    }
                    ngOnChanges(e) {
                        e.rollValues && this.barHighlight()
                    }
                    ngOnInit() {
                        this.diceResultPointRef.nativeElement.style.setProperty("--delayAnimationPoint", "0.6")
                    }
                    get underBarFill() {
                        return 100 - +this.rollValues.over
                    }
                    get overBarFill() {
                        return +this.rollValues.under
                    }
                    get point() {
                        return {
                            left: `${this.rollNumber}%`
                        }
                    }
                    barHighlight(e = null) {
                        this.overDisabled = !1, this.underDisabled = !1, "under" == e ? this.overDisabled = !0 : "over" == e && (this.underDisabled = !0)
                    }
                }
                return n.\u0275fac = function(e) {
                    return new(e || n)
                }, n.\u0275cmp = t.Xpm({
                    type: n,
                    selectors: [
                        ["app-result"]
                    ],
                    viewQuery: function(e, s) {
                        if (1 & e && t.Gf(tt, 7), 2 & e) {
                            let o;
                            t.iGM(o = t.CRH()) && (s.diceResultPointRef = o.first)
                        }
                    },
                    inputs: {
                        config: "config",
                        rollValues: "rollValues",
                        rollNumber: "rollNumber",
                        win: "win"
                    },
                    features: [t.TTD],
                    decls: 34,
                    vars: 14,
                    consts: [
                        [1, "dice-result-wrapper"],
                        [1, "dice-result"],
                        [1, "dice-number"],
                        ["appAnimatedDigit", "", "classOnAnimationEnd", "win", 3, "isAddClassOnAnimationEnd", "digit", "numberLength", "precision", "duration"],
                        [1, "dice-lines"],
                        [1, "dice-line-ruler"],
                        [1, "progress-group", "my-1", "position-relative"],
                        [1, "progress", "justify-content-end"],
                        ["role", "progressbar", 1, "progress-bar", "over-bar"],
                        [1, "progress", 2, "margin-top", "10px"],
                        ["role", "progressbar", 1, "progress-bar", "under-bar"],
                        [1, "dice-result-point", 3, "ngStyle"],
                        ["diceResultPointRef", ""]
                    ],
                    template: function(e, s) {
                        1 & e && (t.TgZ(0, "div", 0), t.TgZ(1, "div", 1), t.TgZ(2, "div", 2), t._UZ(3, "span", 3), t.qZA(), t.TgZ(4, "div", 4), t.TgZ(5, "div", 5), t._UZ(6, "div"), t._UZ(7, "div"), t._UZ(8, "div"), t._UZ(9, "div"), t._UZ(10, "div"), t.qZA(), t.TgZ(11, "div", 6), t.TgZ(12, "div", 7), t._UZ(13, "div", 8), t.qZA(), t.TgZ(14, "div", 9), t._UZ(15, "div", 10), t.qZA(), t._UZ(16, "div", 11, 12), t.qZA(), t.TgZ(18, "div", 5), t.TgZ(19, "div"), t.TgZ(20, "span"), t._uU(21, "0"), t.qZA(), t.qZA(), t.TgZ(22, "div"), t.TgZ(23, "span"), t._uU(24, "25"), t.qZA(), t.qZA(), t.TgZ(25, "div"), t.TgZ(26, "span"), t._uU(27, "50"), t.qZA(), t.qZA(), t.TgZ(28, "div"), t.TgZ(29, "span"), t._uU(30, "75"), t.qZA(), t.qZA(), t.TgZ(31, "div"), t.TgZ(32, "span"), t._uU(33, "100"), t.qZA(), t.qZA(), t.qZA(), t.qZA(), t.qZA(), t.qZA()), 2 & e && (t.xp6(3), t.Q6J("isAddClassOnAnimationEnd", s.win)("digit", s.rollNumber)("numberLength", 5)("precision", 2)("duration", 500), t.xp6(9), t.ekj("disabled", s.overDisabled), t.xp6(1), t.Udp("width", s.overBarFill, "%"), t.xp6(1), t.ekj("disabled", s.underDisabled), t.xp6(1), t.Udp("width", s.underBarFill, "%"), t.xp6(1), t.Q6J("ngStyle", s.point))
                    },
                    directives: [K, h.PC],
                    styles: ['[_nghost-%COMP%]{width:100%}.dice-result-wrapper[_ngcontent-%COMP%]{width:100%;height:175px}@media (min-width: 768px){.dice-result-wrapper[_ngcontent-%COMP%]{height:200px}}.dice-result-wrapper[_ngcontent-%COMP%]   .dice-result[_ngcontent-%COMP%]{background:rgba(0,0,0,.3);border:1px solid #1e1e1e;border-radius:8px;width:100%;height:100%}.dice-result-wrapper[_ngcontent-%COMP%]   .dice-result[_ngcontent-%COMP%]   .dice-number[_ngcontent-%COMP%]{text-align:center;color:#fff;font-weight:700}.dice-result-wrapper[_ngcontent-%COMP%]   .dice-result[_ngcontent-%COMP%]   .dice-number[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:52px;line-height:1.1923076923}.dice-result-wrapper[_ngcontent-%COMP%]   .dice-result[_ngcontent-%COMP%]   .dice-number[_ngcontent-%COMP%]   .win[_ngcontent-%COMP%]{color:#2fb114}.dice-result-wrapper[_ngcontent-%COMP%]   .dice-result[_ngcontent-%COMP%]   .progress[_ngcontent-%COMP%]{background-color:#cb0a2599;position:relative;height:24px;border-radius:0}@media (min-width: 768px){.dice-result-wrapper[_ngcontent-%COMP%]   .dice-result[_ngcontent-%COMP%]   .progress[_ngcontent-%COMP%]{height:30px}}.dice-result-wrapper[_ngcontent-%COMP%]   .dice-result[_ngcontent-%COMP%]   .progress.disabled[_ngcontent-%COMP%]{opacity:.3;background:rgba(0,0,0,.4);transition:opacity .6s ease}.dice-result-wrapper[_ngcontent-%COMP%]   .dice-result[_ngcontent-%COMP%]   .progress[_ngcontent-%COMP%]:after{content:" ";position:absolute;width:100%;height:100%;background:url(dice-ruler-bg.34d59f925c04f21b.svg) repeat-x}.dice-result-wrapper[_ngcontent-%COMP%]   .dice-result[_ngcontent-%COMP%]   .progress[_ngcontent-%COMP%]   .progress-bar.under-bar[_ngcontent-%COMP%]{background-color:#50e3c2}.dice-result-wrapper[_ngcontent-%COMP%]   .dice-result[_ngcontent-%COMP%]   .progress[_ngcontent-%COMP%]   .progress-bar.over-bar[_ngcontent-%COMP%]{background-color:#13b3f2}.dice-line-ruler[_ngcontent-%COMP%]{display:flex;justify-content:space-between}.dice-line-ruler[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{width:1px;height:8px;background-color:#ffffff82}.dice-line-ruler[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:10px;display:inline-block;transform:translate(-50%);padding-top:10px}.dice-line-ruler[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:first-child   span[_ngcontent-%COMP%]{transform:translate(0)}.dice-line-ruler[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:last-child   span[_ngcontent-%COMP%]{transform:translate(-100%)}.dice-result-point[_ngcontent-%COMP%]{position:absolute;top:50%;width:28px;height:28px;border-radius:50%;background-image:linear-gradient(61deg,#fe9702 2%,#fcd605 99%);box-shadow:0 2px 4px #00000080,0 2px 10px #bd10e0;transform:translate(-50%,calc(-50% - 2px));transition:left calc(var(--delayAnimationPoint) * 1s) ease}.dice-result-point[_ngcontent-%COMP%]:after{content:" ";position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:7px;height:7px;border-radius:50%;background:#040837}']
                }), n
            })();
            var et = r(8269),
                it = r(6064),
                nt = r(2983),
                st = r(4219),
                ot = r(425),
                rt = r(3031);
            let m = class {
                constructor(i, e, s, o, a, g, f, x, ut) {
                    this.core = i, this.connector = e, this.betControls = s, this.disableBtnBetService = o, this.sound = a, this.ifcSeenderService = g, this.maxWinService = f, this.toast = x, this.translocoService = ut, this.GameKey = R.R, this.history = [], this._rollValues = {
                        under: "0",
                        over: "0"
                    }, this.isDisabledControls = !1, this.isBetAutoPlay = !1
                }
                ngOnInit() {
                    this.maxWinService.profit = 0, this.betControls.show([c.w.DiceOver, c.w.DiceUnder, c.w.Autoplay]), this.betControls.onAction$.pipe((0, E.h)(i => i.name == c.w.DiceOver || i.name == c.w.DiceUnder || i.name == c.w.Autoplay), (0, u.t)(this)).subscribe(i => this.onMakeBet(i)), this.connector.response(k.E.Bet).pipe((0, u.t)(this)).subscribe(i => {
                        if (this.ifcSeenderService.startRound(i), 200 !== i.code) return this.isBetAutoPlay = !1, this.betControls.errorBetResponse(), void(this.isDisabledControls = !1);
                        this.disableBtnBetService.initDisable(), this.betResponse(i)
                    }), this.core.freeBets.onResetFreeBet$.pipe((0, u.t)(this)).subscribe(() => {
                        this.isBetAutoPlay = !1, this.betControls.enableAll(), this.isDisabledControls = !1, this.core.invokeEndRound()
                    })
                }
                ngAfterViewInit() {
                    this.controls.onChange.pipe((0, u.t)(this)).subscribe(i => {
                        this.rollValues = i
                    }), this.controls.checkProfit.pipe((0, u.t)(this)).subscribe(i => {
                        this.maxWinService.profit = i
                    }), this.rollValues = this.controls.rollValues
                }
                get config() {
                    return this.core.config
                }
                get gameConfig() {
                    return this.core.gameConfig
                }
                get betAmount() {
                    return this.betControls.betAmount
                }
                get rollValues() {
                    return this._rollValues
                }
                set rollValues(i) {
                    this._rollValues = i, this.betControls.updateControlData(c.w.DiceOver, i.over), this.betControls.updateControlData(c.w.DiceUnder, i.under)
                }
                onMakeBet(i) {
                    const e = i.name;
                    this.isBetAutoPlay = e === c.w.Autoplay;
                    const s = e === c.w.Autoplay ? i.data.diceType : e.replace("dice", "").toLowerCase(),
                        o = parseFloat(this.rollValues[s]);
                    this.makeBet(s, o)
                }
                makeBet(i, e) {
                    if (this.core.isBalanceInsufficientForBet(this.betControls.betAmount)) return this.toast.showError(this.translocoService.translate("shared.balance_not_enough")), void(this.betControls.autoplay.isActive && (this.betControls.autoplayHandler(null), this.betControls.enable([c.w.Autoplay])));
                    this.isDisabledControls = !0, this.betControls.disableAll(), this.result.barHighlight(i);
                    const s = this.betControls.adjustBet();
                    this.ifcSeenderService.makeBet(s);
                    const a = this.core.invokeStartRound(s, {
                        type: i,
                        number: e
                    });
                    this.connector.request(F.T.Bet, a)
                }
                betResponse(i) {
                    return (0, b.mG)(this, void 0, void 0, function*() {
                        this.sound.playSound(C.pD.diceBallMove), this.result.rollNumber = i.diceNumber, this.result.win = i.win, yield(0, O.V)(600), i.win && this.sound.playSound(C.pD.softWin), this.history = [{
                            diceNumber: i.diceNumber,
                            win: i.win
                        }, ...this.history.slice(0, 59)], yield(0, O.V)(this.config.minRoundDurationInMillis), this.isDisabledControls = !1, this.betControls.enableAll(), this.betControls.onBetResponse({
                            winAmount: i.winAmount,
                            win: i.win,
                            betAmount: i.betAmount
                        }), this.betControls.autoplay.isActive ? this.makeBet(i.betType, i.betNumber) : this.isBetAutoPlay && this.ifcSeenderService.startAutoplay(!1), this.ifcSeenderService.endRound(i), this.core.invokeEndRound(i, !this.betControls.autoplay.isActive)
                    })
                }
                ngOnDestroy() {}
            };
            m.\u0275fac = function(i) {
                return new(i || m)(t.Y36(P.p), t.Y36(et.v), t.Y36(M.l), t.Y36(it.i), t.Y36(C.yu), t.Y36(nt.S), t.Y36(A.a), t.Y36(st.k), t.Y36(v.Vn))
            }, m.\u0275cmp = t.Xpm({
                type: m,
                selectors: [
                    ["app-dice"]
                ],
                viewQuery: function(i, e) {
                    if (1 & i && (t.Gf(d, 7), t.Gf(w, 7)), 2 & i) {
                        let s;
                        t.iGM(s = t.CRH()) && (e.controls = s.first), t.iGM(s = t.CRH()) && (e.result = s.first)
                    }
                },
                decls: 7,
                vars: 8,
                consts: [
                    [1, "w-100", "h-100", "d-flex", "flex-column", "justify-content-md-center", "align-items-center", "px-1"],
                    [1, "history-wrapper", "w-100"],
                    [3, "game", "history"],
                    [1, "max-win"],
                    [1, "dice-wrapper"],
                    [3, "config", "rollValues"],
                    [1, "mt-1", "mt-md-3", 3, "config", "gameConfig", "isDisabled", "betAmount"]
                ],
                template: function(i, e) {
                    1 & i && (t.TgZ(0, "div", 0), t.TgZ(1, "div", 1), t._UZ(2, "app-rounds-history", 2), t._UZ(3, "app-max-win", 3), t.qZA(), t.TgZ(4, "div", 4), t._UZ(5, "app-result", 5), t._UZ(6, "app-controls", 6), t.qZA(), t.qZA()), 2 & i && (t.xp6(2), t.Q6J("game", e.GameKey.Dice)("history", e.history), t.xp6(3), t.Q6J("config", e.config)("rollValues", e.rollValues), t.xp6(1), t.Q6J("config", e.config)("gameConfig", e.gameConfig)("isDisabled", e.isDisabledControls)("betAmount", e.betAmount))
                },
                directives: [ot.w, rt.y, w, d],
                styles: [".history-wrapper[_ngcontent-%COMP%]{position:relative;max-width:600px;margin-bottom:20px}@media (max-width: 767.98px){.history-wrapper[_ngcontent-%COMP%]{margin-bottom:0;margin-top:5px}}.dice-wrapper[_ngcontent-%COMP%]{width:100%}@media (max-width: 767.98px){.dice-wrapper[_ngcontent-%COMP%]{margin-bottom:auto;margin-top:auto}}.max-win[_ngcontent-%COMP%]{position:absolute;right:0;bottom:0;transform:translateY(calc(100% + 3px))}@media (min-width: 768px){.max-win[_ngcontent-%COMP%]{display:none}}"]
            }), m = (0, b.gn)([(0, u.c)()], m);
            let at = (() => {
                    class n {}
                    return n.\u0275fac = function(e) {
                        return new(e || n)
                    }, n.\u0275mod = t.oAB({
                        type: n
                    }), n.\u0275inj = t.cJS({
                        imports: [
                            [h.ez]
                        ]
                    }), n
                })(),
                lt = (() => {
                    class n {}
                    return n.\u0275fac = function(e) {
                        return new(e || n)
                    }, n.\u0275mod = t.oAB({
                        type: n
                    }), n.\u0275inj = t.cJS({
                        imports: [
                            [h.ez, at]
                        ]
                    }), n
                })();
            const ct = [{
                path: "",
                component: m
            }];
            let ht = (() => {
                class n {}
                return n.\u0275fac = function(e) {
                    return new(e || n)
                }, n.\u0275mod = t.oAB({
                    type: n
                }), n.\u0275inj = t.cJS({
                    imports: [
                        [h.ez, _.Bz.forChild(ct), lt, U, D.z, T.p]
                    ]
                }), n
            })()
        }
    }
]);